import json
import asyncio
import socket
import os
import concurrent.futures
import dns.resolver

from generate_lists import process_domain
from certificates import analyze_domain_certificates
from whois_similarity import get_malicious_domains_from_registrars
from html_scanner import scan_domains
from html_analysis import write_all_html_analysis
from ips_statsistics import compare_ips_and_write_diffs
from concurrent.futures import ThreadPoolExecutor
from domain_live import check_live_domains
from parked_filter import get_parked_domains,  domain_connections, domain_connections_opposite 
from github_scan import scan_github_domain
from google_queries.google_main import run_scanner


def load_json(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)


class MaliciousDomainsSaver:
    def __init__(self, parent_domain):
        self.parent_domain = parent_domain
        self.data = {
            "parent_domain": parent_domain,
            "suspicious_domains": {}
        }

    def add_flag(self, domain, source, reason, details=None):
        if domain not in self.data["suspicious_domains"]:
            self.data["suspicious_domains"][domain] = []
        self.data["suspicious_domains"][domain].append({
            "source": source,
            "reason": reason,
            "details": details
        })

    def save(self):
        os.makedirs("malicious_domains", exist_ok=True)
        path = f"malicious_domains/{self.parent_domain}.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=2, ensure_ascii=False)
        print(f"[+] Saved all suspicious domains in {path}")


def google_scan_and_flag(saver, suspicious_domains):
    """
    For each suspicious domain, run Google scan and add results if malicious likelihood > 50%.
    """
    for domain in suspicious_domains:
        try:
            results_json = run_scanner(domain, output=None, delay=0)
            results = results_json.get("results", [])
            malicious_entries = []
            for entry in results:
                analysis = entry.get("analysis", {})
                if analysis.get("verdict") == "malicious":
                    malicious_entries.append({
                        "url": entry.get("url"),
                        "reasoning": analysis.get("reasoning")
                    })
            total = len(results)
            malicious_count = len(malicious_entries)
            if total == 0:
                continue
            likelihood = malicious_count / total
            if likelihood > 0.5:
                saver.add_flag(
                    domain,
                    source="google_scan",
                    reason=f"Malicious likelihood {int(likelihood * 100)}%",
                    details={
                        "malicious_likelihood_percent": int(likelihood * 100),
                        "malicious_urls": [
                            {
                                "url": e["url"],
                                "reasoning": e["reasoning"]
                            }
                            for e in malicious_entries
                        ]
                    }
                )
        except Exception as e:
            print(f"[Error] Google scan failed for {domain}: {e}")

def main():
    domain = "cyberark.com"
    company_name = "cyberark"
    
    print("[*] Generating high and low confidence domain lists...")
    process_domain(domain, company_name)
    print("[+] Domain list generation complete.\n")
    high_conf_path = f"results/high_conf_domains_{domain}_all.json"
    low_conf_path = f"results/low_conf_domains_{domain}_all.json"

    high_conf_domains = load_json(high_conf_path)
    low_conf_domains = load_json(low_conf_path)
    print("[*] Checking which domains are live (HTTP response)...")
    high_conf_res = check_live_domains(domain, [d["domain_name"] for d in high_conf_domains], is_low=False)
    low_conf_res = check_live_domains(domain, [d["domain_name"] for d in low_conf_domains], is_low=True)

    live_high_conf = high_conf_res['resolving']
    live_low_conf = low_conf_res['resolving']

    print(f"[+] Live high-confidence domains: {len(live_high_conf)}")
    print(f"[+] Live low-confidence domains: {len(live_low_conf)}")
    print("[*] Running headless browser scraping...")
    asyncio.run(scan_domains(live_low_conf))
    print("[+] Web scraping complete.\n")

    saver = MaliciousDomainsSaver(parent_domain=domain)

    print("[*] Filtering parked domains from live domains...")
    parked_low_conf = set(get_parked_domains(live_low_conf))
    parked_high_conf = set(get_parked_domains(live_high_conf))

    final_low_conf_list = [d for d in live_low_conf if d not in parked_low_conf]
    final_high_conf_list = [d for d in live_high_conf if d not in parked_high_conf]
    subsidiaries = [d for d in final_high_conf_list if d != domain]

    print(f"[+] Final usable low-confidence domains: {len(final_low_conf_list)}")
    print(f"[+] Final usable high-confidence domains: {len(final_high_conf_list)}")

    connections  = domain_connections(final_high_conf_list, final_low_conf_list) 
    connections_opposite  = domain_connections_opposite(final_high_conf_list, final_low_conf_list)
    
    for conn_dict in (connections, connections_opposite):
        for low_domain, reasons_list in conn_dict.items():
            if low_domain in final_low_conf_list:
                final_high_conf_list.append(low_domain)
                final_low_conf_list.remove(low_domain)

    print("[*] Running GPT-based HTML + screenshot analysis...")
    mal_results, related_results = write_all_html_analysis(
        high_conf_domain=domain,
        company_name=company_name,
        low_conf_domains=final_low_conf_list,
        subsidiaries=subsidiaries
    )
    print(f"[+] HTML GPT analysis complete. {len(mal_results)} suspicious domains detected.\n")

    for r in mal_results:
        d = r["domain"]
        reason = r["gpt_analyse"].get("malicious_reason", "No reason given")
        saver.add_flag(d, source="html_analysis", reason=reason, details=r["gpt_analyse"])

    print("[*] Running GitHub scan for related domains...")
    for r in related_results:
        d = r["domain"]
        try:
            github_info = scan_github_domain(d)
            if github_info and "malicious_score" in github_info and github_info["malicious_score"] > 50:
                github_entry = {
                    "github_malicious_score": f"{github_info['malicious_score']}%",
                    "github_repos": [
                        {
                            "repo_url": repo.get("url"),
                            "explanation": ctx.get("explanation")
                        }
                        for repo, ctx in zip(github_info.get("repos", []), github_info.get("malicious_contexts", []))
                    ]
                }
                saver.add_flag(d, source="github_scan", reason="Malicious GitHub presence", details=github_entry)
        except Exception as e:
            print(f"[Error] GitHub scan failed for {d}: {e}")

    print("[*] Running IP metadata analysis...")
    ip_results = compare_ips_and_write_diffs(
        domain=domain,
        low_conf_domains=[r["domain"] for r in related_results],
        high_conf_domains=final_high_conf_list
    )
    print(f"[+] IP analysis complete. {len(ip_results)} suspicious results.\n")

    for result in ip_results:
        flagged_domain = result.get("low_conf_domain")
        if not flagged_domain:
            continue
        diffs = result.get("diffs", {})
        if diffs:
            reason = "Suspicious IP metadata"
            saver.add_flag(flagged_domain, source="ip_analysis", reason=reason, details=diffs)

    print("[*] Running SSL certificate comparison...")
    cert_results = analyze_domain_certificates(
        domain=domain,
        high_conf_domains=final_high_conf_list,
        low_conf_domains=[r["domain"] for r in related_results]
    )
    print(f"[+] Certificate analysis complete. {len(cert_results)} suspicious entries.\n")

    for r in cert_results:
        flagged_domain = r.get("domain")
        reasons = []
        if not r.get("issuer_match", True):
            reasons.append("issuer mismatch")
        if not r.get("validity_match", True):
            reasons.append("unusual validity period")
        if r.get("self_signed", False):
            reasons.append("self-signed certificate")

        reason_str = "; ".join(reasons) if reasons else "Certificate anomaly"

        saver.add_flag(flagged_domain, source="certificate_analysis", reason=reason_str, details=r)

    high_live = [h for h in high_conf_domains if h['domain_name'] in final_high_conf_list]
    low_live = [l for l in low_conf_domains if l['domain_name'] in final_low_conf_list]

    print("[*] Analyzing registrars for low-confidence domains...")
    registrar_results = get_malicious_domains_from_registrars(low_live, high_live)
    print(f"[+] Registrar analysis complete. {len(registrar_results)} flagged domains.\n")

    for r in registrar_results:
        d = r.get("domain")
        reason = r.get("reason", "Suspicious registrar or WHOIS mismatch")
        saver.add_flag(d, source="registrar_analysis", reason=reason, details=r)

    saver.save()

    print("[*] Running Google scan for all suspicious domains...")
    suspicious_domains = list(saver.data["suspicious_domains"].keys())
    google_scan_and_flag(saver, suspicious_domains)
    saver.save()
    print("[+] Google scan complete.\n")


if __name__ == "__main__":
    main()
