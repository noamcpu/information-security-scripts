from datetime import datetime
import os, time, re, csv, subprocess
from threading import Lock
import tldextract, msvcrt
from concurrent.futures import ProcessPoolExecutor, as_completed

file_lock = Lock()

def get_all_tlds():
    with open('queries/tlds_all.txt', 'r', encoding='utf-8') as f:
        return [line.strip() for line in f if line.strip()]

def get_popular_tlds():
    with open('queries/tlds_popular.txt', 'r', encoding='utf-8') as f:
        return [line.strip() for line in f if line.strip()]

def generate_domains(domain, tlds):
    ext = tldextract.extract(domain)
    prefix = f"{ext.subdomain}.{ext.domain}".strip('.')
    return [f"{prefix}.{tld}" for tld in tlds]

def safe_delete(path, retries=10, delay=0.2):
    for _ in range(retries):
        try:
            if os.path.exists(path): os.remove(path)
            return
        except PermissionError: time.sleep(delay)
        except Exception as e:
            print(f"Error deleting {path}: {e}"); return
    print(f"[FAIL] Could not delete {path} after retries.")

def wait_until_readable(path, timeout=10):
    start = time.time()
    while time.time() - start < timeout:
        try:
            with open(path, 'r+', encoding='utf-8') as f:
                msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
                msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
                print(f"[Success] read {path}")
                return f.readlines()
        except Exception:
            time.sleep(0.1)
    print(f"[FAIL] Could not read {path}")
    return []


def get_unique_path(base_path):
    if not os.path.exists(base_path):
        return base_path

    base, ext = os.path.splitext(base_path)
    counter = 1
    new_path = f"{base}_{counter}{ext}"
    while os.path.exists(new_path):
        counter += 1
        new_path = f"{base}_{counter}{ext}"
    return new_path


def process_batch(batch_id, domains, exe_path, input_dir):
    os.makedirs(input_dir, exist_ok=True)

    initial_input_path = os.path.join(input_dir, f"{batch_id}.txt")
    input_path = get_unique_path(initial_input_path)

    with open(input_path, 'w', encoding='utf-8') as f:
        f.writelines(f"{d},{d}\n" for d in domains)

    result = subprocess.run([exe_path, input_path], capture_output=True, text=True)
    match = re.search(r'Wrote \d+ records to (C:\\temp\\dns\\a-records-.*?\.csv)', result.stdout)
    output_file = match.group(1) if match else None
    print(f"found output path: {output_file}")

    resolved = set()
    if output_file:
        lines = wait_until_readable(output_file)
        for row in csv.reader(lines, delimiter='\t'):
            if row:
                resolved.add(row[0].split(',')[0].strip())

        with file_lock:
            safe_delete(output_file)
            safe_delete(output_file.replace('a-', 'cname-'))

    for extra in [input_path, f"{input_path}.lastline.txt"]:
        safe_delete(extra)

    return resolved

# kobi batches are 50K domains and output file is a single one per 50K, so batch size needs to be 50K. 
def find_resolving_domains(base_domain, domains, batch_size=50000):
    os.makedirs('tlds', exist_ok=True)
    os.makedirs(r'C:\\temp\\dns', exist_ok=True)
    exe_path = os.path.join(os.path.dirname(__file__), 'dnsvalidator_with_args.exe')
    all_tld_list = get_all_tlds()
    tld_list = get_popular_tlds()

    candidates = []
    for domain in domains:
        if domain == base_domain:
            candidates.extend(generate_domains(domain, all_tld_list))
        else:
            candidates.extend(generate_domains(domain, tld_list))

    print(f"Total candidates generated: {len(candidates)}")
    batches = [candidates[i:i + batch_size] for i in range(0, len(candidates), batch_size)]
    resolved = set()

    with ProcessPoolExecutor(max_workers=5) as executor:
        futures = []
        for i, batch in enumerate(batches):
            futures.append(executor.submit(process_batch, f"{base_domain}_batch_{i}", batch, exe_path, 'tlds'))

        for future in as_completed(futures):
            resolved.update(future.result())

    return list(resolved)

'''
if __name__ == "__main__":
    print(find_resolving_domains('cyberark.com', ['cyberark.com', 'cyberark.jp']))
'''