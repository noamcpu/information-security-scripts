import json
import os
import pandas as pd
from queries.firebolt_queries import execute_query
from queries.athena import order_query_result
import tldextract


def get_low_conf_tlds(domain):
    output_path = f"outputs/low_conf_tlds_{domain}.json"
    if os.path.exists(output_path):
        with open(output_path, 'r', encoding='utf-8') as file:
            return json.load(file)
    with open(f'outputs/high_confidence_{domain}.json', 'r', encoding='utf-8') as file:
        domain_list = json.load(file)
        domain_list = [d['domain_name'] for d in domain_list]
        domain_list = [tldextract.extract(d).domain for d in domain_list]

    or_list = " OR ".join (f"domain = '{d}'" for d in domain_list)
    query = f"""
    SELECT DISTINCT
        domain_name,
        create_date,
        expiry_date,
        domain_registrar_name,
        registrant_name,
        registrant_company,
        registrant_email,
        registrant_phone,
        administrative_name,
        administrative_company,
        administrative_email,
        administrative_phone,
        technical_name,
        technical_company,
        technical_email,
        technical_phone,
        billing_name,
        billing_company,
        billing_email,
        billing_phone
    from malanta_whois_data_v where ({or_list}) 
    AND TRY_CAST(expiry_date AS DATE) > CURRENT_DATE
    """
    rows = execute_query(query)
    columns = [
        "domain_name", "create_date", "expiry_date", "domain_registrar_name",
        "registrant_name", "registrant_company", "registrant_email", "registrant_phone",
        "administrative_name", "administrative_company", "administrative_email", "administrative_phone",
        "technical_name", "technical_company", "technical_email", "technical_phone",
        "billing_name", "billing_company", "billing_email", "billing_phone"
    ]
    df = pd.DataFrame(rows, columns=columns)
    print(df)
    df = order_query_result(df)

    # filter duplicates
    non_empty_counts = df.apply(lambda row: row.notna() & (row != ''), axis=1).sum(axis=1)
    df['non_empty_count'] = non_empty_counts
    df = df.sort_values(['domain_name', 'non_empty_count'], ascending=[True, False])
    df = df.drop_duplicates(subset='domain_name', keep='first')
    df = df.drop(columns='non_empty_count')

    df.to_json(output_path, orient="records", indent=2)
    return json.loads(df.to_json(orient="records"))



#get_low_conf_tlds("cyberark.com")