from gpt import ask_openai
import json

def get_subsidiaries_and_parent(domain, company_name):
    """
    Uses GPT to extract a list of domains belonging to the parent company and subsidiaries.

    Args:
        domain (str): The main domain (e.g., 'pnc.com')
        company_name (str): The known company name (e.g., 'PNC')

    Returns:
        list of str: List of related domains, including the original domain
    """
    prompt = f"""
You are a company intelligence system. Given a main domain "{domain}" and company name "{company_name}", 
return a JSON list of all domains owned by its parent company and direct subsidiaries.

Only include domains that are officially or clearly used by these companies. Return only a flat list of domain strings.
Example output: ["pnc.com", "pncinvestments.com", "harrisdirect.com"]

Now generate the list for company "{company_name}".
    """

    try:
        response = ask_openai(prompt)

        # Handle string or dict or list response formats
        if isinstance(response, list):
            domain_list = response
        elif isinstance(response, dict):
            # Sometimes the LLM wraps response in a dict with key like "domains"
            domain_list = response.get("domains") or response.get("related_domains") or []
        elif isinstance(response, str):
            response = response.strip()
            domain_list = json.loads(response)
        else:
            print(f"[Warning] Unexpected GPT response type: {type(response)}")
            return []

        if not isinstance(domain_list, list):
            print(f"[Warning] GPT did not return a list for {company_name}: {response}")
            return []

        return [d.lower().strip() for d in domain_list if isinstance(d, str)]

    except Exception as e:
        print(f"[Error] Failed to get subsidiaries from GPT for {company_name}: {e}")
        return []
