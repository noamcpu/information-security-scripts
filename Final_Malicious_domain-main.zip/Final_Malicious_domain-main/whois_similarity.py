import re


# it needs to get the high and low conf as list of json objects with the full data. 
def get_malicious_domains_from_registrars(high_conf_domains, low_conf_domains):
    potential_malicious = []
    registrar_blacklist = [
        "alibaba", "namecheap", "pdr ltd", "namesilo", "gmo", "dynadot", "wild west domains",
        "1api", "xin net", "hichina", "domain international", "nicenic", "name.com", "dominet", "url solutions"
    ]

    # Extract unique registrars from high-confidence domains (case-insensitive)
    high_conf_registrars = set(
        domain_data.get("domain_registrar_name", "").lower()
        for domain_data in high_conf_domains
        if domain_data.get("domain_registrar_name")
    )

    # Filter blacklist to exclude registrars present in high-confidence domains
    registrar_blacklist = [
        black for black in registrar_blacklist
        if not any(black.lower() in high_reg for high_reg in high_conf_registrars)
    ]

    print(f"High-confidence registrars: {list(high_conf_registrars)}")
    print(f"Filtered blacklisted registrars: {registrar_blacklist}")

    # Regex to detect non-Latin characters (non-English scripts)
    non_latin_pattern = re.compile(r'[^\x00-\x7F]+')

    for domain_data in low_conf_domains:
        registrar = domain_data.get("domain_registrar_name", "")
        registrar = registrar.lower() if registrar else ""

        if not registrar:
            continue
        # Check for blacklisted registrar
        for black_registrar in registrar_blacklist:
            if black_registrar.lower() in registrar:
                potential_malicious.append(domain_data)
                break

        # Check for non-English registrar (not in high-confidence domains)
        if non_latin_pattern.search(domain_data.get("domain_registrar_name", "")) and registrar not in high_conf_registrars:
            potential_malicious.append(domain_data)

    return potential_malicious
