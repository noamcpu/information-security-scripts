import openai
import json
from .google_config import DEFAULT_MAX_TOKENS

def ask_openai(prompt, system_content="You are an expert reading html content and identify malicious activity"):
    openai.api_key = "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"

    response = openai.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": system_content},
            {"role": "user", "content": prompt}
        ],
        max_tokens=DEFAULT_MAX_TOKENS,
        temperature=0
    )
    generated_content = response.choices[0].message.content
    json_data = generated_content.replace('```json', '').replace('```', '').strip()
    
    return json.loads(json_data)
