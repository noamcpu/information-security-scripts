import openai
import json
import base64


def ask_openai(prompt):
    openai.api_key = "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"

    try:
        response = openai.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are an expert reading html content and identify malicious activity"},
                    {"role": "user", "content": prompt},
                ]
            )
        # Use attribute access for new OpenAI SDK
        content = response.choices[0].message.content
        json_data = content.replace('```json', '').replace('```', '').strip()
        return json.loads(json_data)
    except Exception as e:
        # Always return a dict for error, not a list or string
        return {
            "category": "",
            "related": False,
            "related_reason": f"Error: {str(e)}",
            "malicious": False,
            "malicious_reason": f"Error: {str(e)}"
        }


def encode_image_to_base64(image_path):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')

def analyze_images(image_paths, prompt):
    openai.api_key = "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"

    try:
        # Build the content list with text + all images
        message_content = [{"type": "text", "text": prompt}]
        
        for path in image_paths:
            base64_img = encode_image_to_base64(path)
            message_content.append({
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/jpeg;base64,{base64_img}"
                }
            })

        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are an expert in visual analysis. Respond based on all the images provided."},
                {"role": "user", "content": message_content}
            ],
            max_tokens=2000
        )
        # Use attribute access for new OpenAI SDK
        result = response.choices[0].message.content
        json_data = result.replace('```json', '').replace('```', '').strip()
        return json.loads(json_data)
    except Exception as e:
        # Always return a dict for error, not a string
        return {
            "category": "",
            "related": False,
            "related_reason": f"Error: {str(e)}",
            "malicious": False,
            "malicious_reason": f"Error: {str(e)}"
        }