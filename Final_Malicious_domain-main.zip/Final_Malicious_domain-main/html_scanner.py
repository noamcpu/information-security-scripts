import asyncio
import contextlib
import json
import os
import time
from urllib.parse import urlparse, urljoin
from playwright.async_api import async_playwright
 
TIMEOUT_MS = 30000
MAX_CONCURRENT_BROWSERS = 5
MAX_CONCURRENT_TABS_PER_BROWSER = 10
MAX_DOMAINS_PER_BROWSER_CONTEXT = 100
OUTPUT_DIR = "html"
IMAGES_DIR = "images"
 
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(IMAGES_DIR, exist_ok=True)
 
def trim_schema(s):
    for k, v in list(s.items()):
        if isinstance(v, str):
            s[k] = v.strip().replace('\n', ' ')
        elif isinstance(v, list):
            cleaned_list = []
            for item in v:
                if isinstance(item, str):
                    cleaned_item = item.strip().replace('\n', ' ')
                    if cleaned_item:
                        cleaned_list.append(cleaned_item)
                elif item is not None:
                    cleaned_list.append(item)
            s[k] = list(dict.fromkeys(cleaned_list))
    return s
 
async def async_save(schema):
    filename_domain = schema.get("domain", "unknown_domain")
    file_path = os.path.join(OUTPUT_DIR, f"{filename_domain}_html.json")
    try:
        loop = asyncio.get_running_loop()
        json_data = await loop.run_in_executor(
            None,
            lambda s, ea, ind: json.dumps(s, ensure_ascii=ea, indent=ind),
            schema, False, 2
        )
        await loop.run_in_executor(
            None,
            lambda: open(file_path, "w", encoding="utf-8").write(json_data)
        )
        print(f"[+] Schema saved for {schema['domain']}")
    except Exception as e:
        print(f"[-] Error saving schema for {schema['domain']}: {e}")
 
async def scrape(page, domain):
    schema = {
        "domain": domain,
        "title": "",
        "body_text": "",
        "headers": [],
        "favicon": "",
        "redirect_chain": [],
        "hrefs": [],
        "auth_provider": None,
        "error": ""
    }
 
    initial_url = f"http://{domain}"
    redirect_chain = []
   
    def track_redirects(request):
        if request.is_navigation_request() and request.url not in redirect_chain:
            redirect_chain.append(request.url)
 
    page.on("request", track_redirects)
 
    try:
        print(f"[+] Navigating to: {initial_url}")
 
        response = None
        for attempt in range(3):
            try:
                response = await page.goto(initial_url, timeout=TIMEOUT_MS)
                if response and response.ok:
                    time.sleep(2)
                    break
                else:
                    status = response.status if response else "No response"
                    print(f"[*] Non-OK response ({status}) for {domain} (attempt {attempt + 1}). Retrying...")
            except Exception as e:
                print(f"[!] Error during navigation for {domain} (attempt {attempt + 1}): {e}")
           
            if attempt < 2:
                await asyncio.sleep(2)
 
        if not response or not response.ok:
            raise Exception(f"Failed to load {domain} after multiple attempts or received non-OK response.")
 
        schema["redirect_chain"] = redirect_chain
       
        results = await asyncio.gather(
            page.title(),
            page.locator("body").inner_text(timeout=TIMEOUT_MS // 3),
            page.evaluate("""
                () => {
                    const links = [...document.getElementsByTagName('link')];
                    const icon = links.find(l => /icon/i.test(l.rel));
                    return icon?.href || '';
                }
            """),
            page.eval_on_selector_all("a[href]", "nodes => nodes.map(n => n.href)"),
            page.locator("h1").all_inner_texts(),
            page.locator("h2").all_inner_texts(),
            page.locator("h3").all_inner_texts(),
            return_exceptions=True
        )
 
        schema["title"] = results[0] if not isinstance(results[0], Exception) else ""
       
        body_text_result = results[1]
        if not isinstance(body_text_result, Exception):
            schema["body_text"] = body_text_result[:10000]
        else:
            schema["body_text"] = f"Body text extraction error: {body_text_result}"
            print(f"[*] Error extracting body text for {domain}: {body_text_result}")
 
        schema["favicon"] = results[2] if not isinstance(results[2], Exception) else ""
       
        all_hrefs = results[3]
        if not isinstance(all_hrefs, Exception):
            filtered_hrefs = set()
            current_page_url = page.url
            for href in all_hrefs:
                if href.startswith("http://") or href.startswith("https://"):
                    filtered_hrefs.add(href)
                elif not urlparse(href).scheme and not urlparse(href).netloc:
                    if current_page_url and not current_page_url.startswith("data:"):
                        try:
                            absolute_url = urljoin(current_page_url, href)
                            filtered_hrefs.add(absolute_url)
                        except Exception as e:
                            print(f"[-] Could not resolve relative URL {href} from {current_page_url}: {e}")
            schema["hrefs"] = list(filtered_hrefs)
        else:
            schema["hrefs"] = []
            print(f"[*] Error extracting hrefs for {domain}: {all_hrefs}")
 
        for i in range(4, 7):
            header_result = results[i]
            if not isinstance(header_result, Exception):
                schema["headers"].extend(h.strip() for h in header_result if h.strip())
            else:
                print(f"[*] Error extracting headers (index {i-4}) for {domain}: {header_result}")
 
        rc = ' '.join(schema["redirect_chain"]).lower()
        if 'login.microsoftonline.com' in rc:
            schema["auth_provider"] = "microsoft"
        elif 'accounts.google.com' in rc:
            schema["auth_provider"] = "google"
 
        screenshot_domain = domain
        screenshot_path = os.path.join(IMAGES_DIR, f"{screenshot_domain}.png")
        await page.screenshot(path=screenshot_path, full_page=True)
        print(f"[+] Screenshot saved for {domain}")
 
    except Exception as e:
        schema["error"] = f"General Error during scrape: {str(e)}"
        print(f"[-] General Error during scrape for {domain}: {e}")
    finally:
        trim_schema(schema)
        await async_save(schema)
        with contextlib.suppress(Exception):
            await page.close()
            print(f"[+] Page closed for {domain}")
 
 
class BrowserPool:
    def __init__(self, p_instance):
        self.p = p_instance
        self.browsers = asyncio.Queue(maxsize=MAX_CONCURRENT_BROWSERS)
        self.browser_sem = asyncio.Semaphore(MAX_CONCURRENT_BROWSERS)
        self.browser_counter = 0
 
    async def _launch_browser(self):
        self.browser_counter += 1
        print(f"[+] Launching new browser (total active: {self.browser_counter})")
        try:
            return await self.p.chromium.launch(
                headless=True,
                args=[
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--disable-gpu',
                    '--disable-dev-shm-usage',
                    '--disable-extensions',
                    '--ignore-certificate-errors',
                    '--disable-http2',
                    '--disable-features=IsolateOrigins,site-per-process',
                    '--window-size=1280,800',
                    '--incognito',
                ]
            )
        except Exception as e:
            self.browser_counter -= 1
            print(f"[-] CRITICAL: Failed to launch browser: {e}")
            raise
 
    async def get_browser(self):
        async with self.browser_sem:
            if self.browsers.empty():
                browser = await self._launch_browser()
            else:
                browser = await self.browsers.get()
                print(f"[*] Reusing browser instance. Queue size: {self.browsers.qsize()}")
            return browser
 
    async def release_browser(self, browser):
        if self.browsers.full():
            print(f"[-] Browser pool full, closing browser.")
            await browser.close()
            self.browser_counter -= 1
        else:
            await self.browsers.put(browser)
 
    async def close_all_browsers(self):
        print("[+] Closing all browsers in the pool...")
        for _ in range(MAX_CONCURRENT_BROWSERS):
            await self.browser_sem.acquire()
 
        while not self.browsers.empty():
            browser = await self.browsers.get()
            try:
                await browser.close()
                self.browser_counter -= 1
            except Exception as e:
                print(f"[-] Error closing browser: {e}")
        print("[+] All browsers closed.")
 
 
async def process_domains_with_browser(browser_pool, domains_queue):
    browser = None
    context = None
    try:
        browser = await browser_pool.get_browser()
       
        domains_processed_in_context = 0
        while True:
            domains_to_process_in_chunk = []
            while domains_processed_in_context < MAX_DOMAINS_PER_BROWSER_CONTEXT and not domains_queue.empty():
                try:
                    domain = domains_queue.get_nowait()
                    domains_to_process_in_chunk.append(domain)
                    domains_processed_in_context += 1
                except asyncio.QueueEmpty:
                    break
 
            if not domains_to_process_in_chunk:
                break
 
            if context:
                with contextlib.suppress(Exception):
                    await context.close()
                    print("[+] Old browser context closed, creating new one.")
           
            context = await browser.new_context(
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/126.0.0.0 Safari/537.36"
                ),
                viewport={"width": 1280, "height": 800},
                locale="en-US",
                java_script_enabled=True,
                ignore_https_errors=True,
                bypass_csp=True,
            )
            print(f"[+] New browser context created for {len(domains_to_process_in_chunk)} domains in this chunk.")
            domains_processed_in_context = 0
 
            sem_tabs = asyncio.Semaphore(MAX_CONCURRENT_TABS_PER_BROWSER)
           
            async def bounded_scrape_wrapper(domain):
                async with sem_tabs:
                    page = None
                    try:
                        page = await context.new_page()
                        await scrape(page, domain)
                    except Exception as e:
                        print(f"[-] Unhandled error during scraping {domain}: {e}")
                    finally:
                        pass
 
            await asyncio.gather(*(bounded_scrape_wrapper(domain) for domain in domains_to_process_in_chunk))
           
            for _ in domains_to_process_in_chunk:
                domains_queue.task_done()
 
    except Exception as e:
        print(f"[-] Error in browser worker process: {e}")
    finally:
        if context:
            with contextlib.suppress(Exception):
                await context.close()
                print("[+] Browser context closed.")
        if browser:
            await browser_pool.release_browser(browser)
 
 
async def scan_domains(domains):
    domains = [d for d in domains if not os.path.exists(os.path.join(OUTPUT_DIR, f"{d}_html.json"))]
    async with async_playwright() as p:
        browser_pool = BrowserPool(p)
       
        domain_queue = asyncio.Queue()
        for domain in domains:
            await domain_queue.put(domain)
       
        print(f"Starting scan for {domain_queue.qsize()} domains...")
 
        workers = []
        for _ in range(MAX_CONCURRENT_BROWSERS):
            workers.append(asyncio.create_task(process_domains_with_browser(browser_pool, domain_queue)))
       
        await domain_queue.join()
        print("[+] All domains processed in the queue.")
 
        for worker in workers:
            if not worker.done():
                worker.cancel()
        await asyncio.gather(*workers, return_exceptions=True)
 
        await browser_pool.close_all_browsers()
        print("Domain scanning complete.")
 

if __name__ == "__main__":
    domains_to_scan = [
        'alero.io'
    ]
 
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs(IMAGES_DIR, exist_ok=True)
    asyncio.run(scan_domains(domains_to_scan))
