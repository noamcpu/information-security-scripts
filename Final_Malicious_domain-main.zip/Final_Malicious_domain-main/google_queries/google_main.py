from google_config import create_scanner_state, DEFAULT_PAGES, DEFAULT_DELAY, DEFAULT_MAX_THREADS
from google_search import search_google
from google_extract_data import check_for_links
import json
import time
import threading
#from google_analysis import run_analysis_on_json

def write_results(state):
    if not state['output_file']:
        return

    try:
        websites_with_mentions = [r for r in state['results'] if r['links_found']]
        url_to_entry = {}

        for result in websites_with_mentions:
            url = result['referring_site']
            html_data = result.get('html_data', {})
            html_content = html_data.get('body_text', '')
            title = html_data.get('title', '')
            headers = html_data.get('headers', [])

            if url not in url_to_entry:
                url_to_entry[url] = {
                    "url": url,
                    "mentions": [],
                    "title": title,
                    "body_text": html_content,
                    "headers": headers
                }
            for mention in result['links_found']:
                if mention not in url_to_entry[url]["mentions"]:
                    url_to_entry[url]["mentions"].append(mention)

        output_data = {
            "summary": {
                "domain": state['domain'],
                "date": time.strftime('%Y-%m-%d %H:%M:%S'),
                "total_unique_urls": len(url_to_entry),
                "total_mentions": sum(len(e["mentions"]) for e in url_to_entry.values())
            },
            "results": list(url_to_entry.values())
        }

        with open(state['output_file'], 'w', encoding='utf-8') as f:
            json.dump(output_data, f, indent=2, ensure_ascii=False)

        print(f"[+] Results written to {state['output_file']}")

    except Exception as e:
        print(f"[!] Error writing results: {str(e)}")

def display_results(state):
    print("\n" + "=" * 70)
    print(f"Results for {state['domain']}")
    print("=" * 70)
    
    websites_with_mentions = [r for r in state['results'] if r['links_found']]
    websites_without_mentions = [r for r in state['results'] if not r['links_found']]

    print(f"\nSummary:")
    print(f"- Total websites checked: {len(state['results'])}")
    print(f"- Websites mentioning the domain: {len(websites_with_mentions)}")
    print(f"- Websites without mentions: {len(websites_without_mentions)}")
    all_mentions_with_urls = set()
    for r in websites_with_mentions:
        for mention in r['links_found']:
            all_mentions_with_urls.add((mention, r['referring_site']))
    print(f"- Total unique mentions found: {len(all_mentions_with_urls)}")
    
    print("\nAll Unique Mentions:")
    print("=" * 70)
    for mention, url in sorted(all_mentions_with_urls, key=lambda x: (x[1], x[0])):
        print(f"- {mention}\n  [URL: {url}]")

    print("\nWebsites WITH Mentions:")
    print("=" * 70)
    for i, result in enumerate(websites_with_mentions, 1):
        print(f"\n{i}. {result['referring_site']}")
        print(f"   Title: {result.get('title', 'N/A')}")
        print(f"   Snippet: {result.get('snippet', 'N/A')}")
        print(f"   Mentions:")
        for link in result['links_found']:
            print(f"   - {link}")
            print(f"     [URL: {result['referring_site']}]")

def search_module(state):
    """Groups all search-related functions"""
    urls = search_google(state)
    check_for_links(state)
    return urls

def process_results_module(state):
    """Groups all results processing functions"""
    display_results(state)

def run_scanner(domain, pages=DEFAULT_PAGES, output=None, delay=DEFAULT_DELAY, max_threads=DEFAULT_MAX_THREADS):
    try:
        state = create_scanner_state(domain, pages, output, delay, max_threads)
        search_module(state)
        process_results_module(state)
        print("\n[*] Search completed.")
        websites_with_mentions = [r for r in state['results'] if r['links_found']]
        url_to_entry = {}
        for result in websites_with_mentions:
            url = result['referring_site']
            html_data = result.get('html_data', {})
            html_content = html_data.get('body_text', '')
            title = html_data.get('title', '')
            headers = html_data.get('headers', [])
            if url not in url_to_entry:
                url_to_entry[url] = {
                    "url": url,
                    "mentions": [],
                    "title": title,
                    "body_text": html_content,
                    "headers": headers
                }
            for mention in result['links_found']:
                if mention not in url_to_entry[url]["mentions"]:
                    url_to_entry[url]["mentions"].append(mention)
        results_json = {
            "summary": {
                "domain": state['domain'],
                "date": time.strftime('%Y-%m-%d %H:%M:%S'),
                "total_unique_urls": len(url_to_entry),
                "total_mentions": sum(len(e["mentions"]) for e in url_to_entry.values())
            },
            "results": list(url_to_entry.values())
        }
        return results_json
    finally:
        for thread in threading.enumerate():
            if thread != threading.current_thread():
                try:
                    thread.join(timeout=1.0)
                except Exception:
                    pass
"""
if __name__ == "__main__":
    try:
        domain = "umisen.com"
        results_json = run_scanner(domain=domain, output=None, delay=0)
    except KeyboardInterrupt:
        print("\n[!] Search interrupted by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n[!] An unexpected error occurred: {str(e)}")
        sys.exit(1)

    run_analysis_on_json(results_json)
"""
