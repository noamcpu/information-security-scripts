import json
import os
from queries.resolve_all_tlds_exe import find_resolving_domains
from queries.low_conf_tlds_firebolt import get_low_conf_tlds
from concurrent.futures import ProcessPoolExecutor, as_completed

def db_format(domain):
    return {
        "domain_name": domain,
        "create_date":"",
        "expiry_date":"",
        "domain_registrar_name":"",
        "registrant_name":"",
        "registrant_company":"",
        "registrant_email":"",
        "registrant_phone":"",
        "administrative_name":"",
        "administrative_company":"",
        "administrative_email":"",
        "administrative_phone":"",
        "technical_name":"",
        "technical_company":"",
        "technical_email":"",
        "technical_phone":"",
        "billing_name":"",
        "billing_company":"",
        "billing_email":"",
        "billing_phone":"",
        "combined_company_names":[],
        "combined_registrant_names":[],
        "combined_emails":[],
        "combined_phone":[]
    }

def get_low_conf_tlds_deep(domain):
    output_path = f"outputs/low_conf_tlds_{domain}.json"
    if os.path.exists(output_path):
        with open(output_path, 'r', encoding='utf-8') as file:
            return json.load(file)
    
    all_results = []
    
    # resolve using firebolt
    firebolt_tlds = get_low_conf_tlds(domain)
    firebolt_tlds_list = [d['domain_name'] for d in firebolt_tlds]

    all_results.extend(firebolt_tlds)
    print(f"got {len(all_results)} tlds from firebolt")
    
    with open(f'outputs/high_confidence_{domain}.json', 'r', encoding='utf-8') as file:
        domain_list = json.load(file)
        domain_list = [d['domain_name'] for d in domain_list]
        
    # calling dnsvalidator 4 times to get as many results as possible. 
    exe_results = []
    with ProcessPoolExecutor(max_workers=4) as executor:
        futures = [executor.submit(find_resolving_domains, domain, domain_list) for domain_list in [domain_list, domain_list, domain_list, domain_list]]
        for future in as_completed(futures):
            resolved_domains = future.result()
            exe_results.extend([resolve for resolve in resolved_domains if resolve not in firebolt_tlds_list])
            
    exe_results = list(set(exe_results)) 
    all_results.extend([db_format(d) for d in exe_results])
    
    print(f'total tlds found for {domain} : {len(all_results)}')
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(all_results, f, ensure_ascii=False)
    
    return all_results

    

#get_low_conf_tlds_deep("cyberark.com")