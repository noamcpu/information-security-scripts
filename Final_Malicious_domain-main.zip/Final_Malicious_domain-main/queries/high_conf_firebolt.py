import json
import os
import pandas as pd
import tldextract
from queries.firebolt_queries import execute_query, execute_multiple_queries
from queries.athena import order_query_result
from functools import lru_cache

@lru_cache(maxsize=1000)
def extract_domain_parts(domain):
    extracted = tldextract.extract(domain)
    return (extracted.domain, extracted.suffix) if extracted.domain and extracted.suffix else (None, None)

def chunk_list(lst, chunk_size):
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]

def build_batch_query(domain_batch):
    domain_values = [
        f"('{parts[0]}', '{parts[1]}')" 
        for domain in domain_batch
        if (parts := extract_domain_parts(domain))[0]
    ]
    if not domain_values:
        return None
    domain_cte = " UNION ALL ".join(
        f"SELECT '{name}' AS email_domain, '{suffix}' AS email_suffix"
        for name, suffix in [d.strip("()").replace("'", "").split(", ") for d in domain_values]
    )
    return f"""
        WITH domains AS (
            {domain_cte}
        ),
        email_domains AS (
            SELECT 
                e.domain, e.suffix,
                ROW_NUMBER() OVER (PARTITION BY e.domain, e.suffix ORDER BY e.query_time DESC) AS rn
            FROM whois_data_emails e
            INNER JOIN domains d
                ON e.email_domain = d.email_domain AND e.email_suffix = d.email_suffix
            WHERE TRY_CAST(e.expiry_date AS DATE) > CURRENT_DATE 
        )
        SELECT DISTINCT w.domain_name,
                        w.create_date,
                        w.expiry_date,
                        w.domain_registrar_name,
                        w.registrant_name,
                        w.registrant_company,
                        w.registrant_email,
                        w.registrant_phone,
                        w.administrative_name,
                        w.administrative_company,
                        w.administrative_email,
                        w.administrative_phone,
                        w.technical_name,
                        w.technical_company,
                        w.technical_email,
                        w.technical_phone,
                        w.billing_name,
                        w.billing_company,
                        w.billing_email,
                        w.billing_phone
        FROM email_domains ed
        JOIN malanta_whois_data_v w
          ON w.domain = ed.domain AND w.suffix = ed.suffix
        WHERE TRY_CAST(w.expiry_date AS DATE) > CURRENT_DATE
              AND w.expiry_date IS NOT NULL
              AND w.expiry_date <> ''
    """


def get_main_domain_data(domain):
    name, suffix = extract_domain_parts(domain)
    if not (name and suffix):
        return []
    query = f"""
    SELECT DISTINCT domain_name,
                    create_date,
                    expiry_date,
                    domain_registrar_name,
                    registrant_name,
                    registrant_company,
                    registrant_email,
                    registrant_phone,
                    administrative_name,
                    administrative_company,
                    administrative_email,
                    administrative_phone,
                    technical_name,
                    technical_company,
                    technical_email,
                    technical_phone,
                    billing_name,
                    billing_company,
                    billing_email,
                    billing_phone
    FROM malanta_whois_data_v
    WHERE domain = '{name}' AND suffix = '{suffix}' AND TRY_CAST(expiry_date AS DATE) > CURRENT_DATE
    """
    rows = execute_query(query)
    columns = [
        "domain_name", "create_date", "expiry_date", "domain_registrar_name",
        "registrant_name", "registrant_company", "registrant_email", "registrant_phone",
        "administrative_name", "administrative_company", "administrative_email", "administrative_phone",
        "technical_name", "technical_company", "technical_email", "technical_phone",
        "billing_name", "billing_company", "billing_email", "billing_phone"
    ]
    df = pd.DataFrame(rows, columns=columns)
    df = order_query_result(df)
    return df.to_dict(orient="records")


def discover_all_linked_domains_firebolt(seed_domain, max_depth = 7, batch_size = 500, max_workers = 8):
    discovered = {seed_domain.lower()}  # Track all discovered domains
    to_query = {seed_domain.lower()}   # Domains to query in current iteration
    all_records = []                 # Store all results

    for depth in range(max_depth):
        if not to_query:
            print(f"[Depth {depth + 1}] No domains to query. Terminating.")
            break

        print(f"[Depth {depth + 1}] Querying {len(to_query)} domains...")

        # Adjust batch size dynamically to optimize for small or large sets
        current_batch_size = min(batch_size, max(10, len(to_query) // max_workers + 1))
        batches = chunk_list(list(to_query), current_batch_size)

        # Build all queries up front
        queries = []
        for batch in batches:
            query = build_batch_query(batch)
            if query:
                queries.append(query)

        # Execute all Firebolt queries at once
        query_results = execute_multiple_queries(queries)

        # Process results
        columns = [
            "domain_name", "create_date", "expiry_date", "domain_registrar_name",
            "registrant_name", "registrant_company", "registrant_email", "registrant_phone",
            "administrative_name", "administrative_company", "administrative_email", "administrative_phone",
            "technical_name", "technical_company", "technical_email", "technical_phone",
            "billing_name", "billing_company", "billing_email", "billing_phone"
        ]
        batch_results = []
        df = pd.DataFrame(query_results, columns=columns)
        batch_results = order_query_result(df).to_dict(orient="records")

        if not batch_results:
            print(f"[Depth {depth + 1}] No results returned. Terminating.")
            break

        # Extract new domains, excluding already discovered ones
        new_domains = {r["domain_name"].lower() for r in batch_results if r.get("domain_name")} - discovered
        if not new_domains:
            print(f"[Depth {depth + 1}] No new domains found. Terminating.")
            break

        # Add new results to all_records
        all_records.extend(batch_results)
        discovered.update(new_domains)
        to_query = new_domains

        print(f"[Depth {depth + 1}] Found {len(new_domains)} new domains.")

    return all_records

def generate_high_conf_results(domain_name):
    output_file = f"outputs/high_confidence_{domain_name}.json"
    if os.path.exists(output_file):
        with open(output_file, 'r', encoding='utf-8') as f:
            return json.load(f)
        
    seen = set()
    all_discovered_data = []
    try:
        # Collect all records from recursive discovery
        all_discovered_data.extend(discover_all_linked_domains_firebolt(domain_name))
        
        # Check if seed domain is in results
        initial_domain_found = any(record.get("domain_name", "").strip() == domain_name for record in all_discovered_data)
        
        # If seed domain is not found, query it directly
        if not initial_domain_found:
            main_domain_data = get_main_domain_data(domain_name)
            if main_domain_data:
                all_discovered_data.extend(main_domain_data)
        
        # Filter out duplicates based on domain_name
        seen = {}
        for record in all_discovered_data:
            domain = record.get("domain_name", "").strip()
            # Count how many non-empty fields are present
            filled_fields = sum(1 for v in record.values() if v not in ("", None))
            if domain not in seen:
                seen[domain] = (filled_fields, record)
            else:
                existing_filled, _ = seen[domain]
                if filled_fields > existing_filled:
                    seen[domain] = (filled_fields, record)

        # Final unique records with most data per domain
        unique_records = [item[1] for item in seen.values()]

        # Save results to file
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(unique_records, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Error writing {output_file}: {e}")
        
        return unique_records
    
    except Exception as e:
        print(f"Error occurred: {str(e)}")
        return []

#generate_high_conf_results('cyberark.com')