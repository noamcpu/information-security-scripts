import json
import re
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed, wait, TimeoutError
from .google_gpt import ask_openai
from .google_config import DEFAULT_MAX_BODY, DEFAULT_MAX_HEADERS

def clean_gpt_json_block(answer):
    match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', answer, re.DOTALL)
    return match.group(1) if match else answer

def ask_gpt_general_analysis(domain, url, title, body_text, headers):
    body_text = (body_text or "")[:DEFAULT_MAX_BODY]
    headers = (headers or [])[:DEFAULT_MAX_HEADERS]
    headers_str = "\n".join(headers)
    prompt = (
        f"Analyze the following information for the domain '{domain}' at URL: {url}.\n"
        f"Title: {title}\n"
        f"Body Text: {body_text}\n"
        f"Headers: {headers_str}\n\n"
        "Determine if the domain is being referenced in a context that suggests it is malicious or benign, considering all the above information together.\n"
        "Malicious context includes (but is not limited to):\n"
        "- The domain appears in threat intelligence feeds, malware lists, blacklists, indicator lists, or any file or repository that collects suspicious domains, EVEN IF the page content is empty, generic, or says 'Loading...'.\n"
        "- The domain is referenced in the URL, title, or headers in a context that might indicate the domain is being tested for malicious activity, or the page is about malware, indicators, or threat intelligence.\n"
        "- The domain is discussed as part of a cyber attack, malware campaign, or security incident.\n"
        "- The domain is listed alongside other known malicious domains or indicators of compromise, even if not explicitly described as malicious.\n"
        "- The domain is referenced in a suspicious file, text list, or repository (e.g., a GitHub repo of bad domains, threat feeds, or malware trackers).\n"
        "- The domain is mentioned in any context that could be interpreted as related to threat intelligence, malware, or cybercrime, even if the evidence is indirect or circumstantial.\n"
        "Benign context includes ONLY:\n"
        "- The domain is clearly mentioned as a vendor, in a neutral context, or as part of a legitimate business or product, with explicit evidence from the content.\n"
        "- The domain is referenced in a news article, research, or forum post with clear, explicit evidence that it is not being associated with malicious activity.\n"
        "If there is any ambiguity, lack of clear evidence, or if the context is indirect, circumstantial, or related to threat intelligence/indicator feeds, classify as 'malicious'.\n"
        "Only classify as 'benign' if there is strong, explicit evidence in the content that the domain is not being associated with malicious activity.\n"
        "Respond strictly in JSON: {\"verdict\": \"malicious\" or \"benign\", \"reasoning\": \"...\"}\n"
        "Be concise but specific in your reasoning, and quote or summarize the evidence from the content or context."
    )
    system_content = "You are an expert reading html content and identify malicious activity"
    result = ask_openai(prompt, system_content=system_content)
    if result is None:
        return {"verdict": "error", "reasoning": "[Error during processing: No response from GPT]"}
    return result

def run_analysis_on_json(input_json, output_path="malicious_likelihood.json", max_workers=50):  # Increased max_workers
    data = input_json
    domain = data["summary"]["domain"]
    url_entries = []
    for entry in data["results"]:
        url_entries.append({
            "url": entry.get("url"),
            "title": entry.get("title", ""),
            "body_text": entry.get("body_text", ""),
            "headers": entry.get("headers", []),
        })

    results = []
    malicious_count = 0
    total_urls = len(url_entries)

    def process_url_entry(entry):
        url = entry["url"]
        title = entry.get("title", "")
        body_text = entry.get("body_text", "")
        headers = entry.get("headers", [])
        try:
            analysis = ask_gpt_general_analysis(domain, url, title, body_text, headers)
        except Exception as e:
            analysis = {"verdict": "error", "reasoning": f"[Error during processing: {str(e)}]"}
        is_malicious = analysis.get("verdict") == "malicious"
        return {
            "url": url,
            "analysis": analysis,
            "malicious": is_malicious
        }

    with ThreadPoolExecutor(max_workers=min(max_workers, total_urls)) as executor:
        futures = [executor.submit(process_url_entry, entry) for entry in url_entries]
        for future in tqdm(as_completed(futures), total=len(futures), desc="Analyzing URLs with GPT"):
            try:
                result = future.result()
            except TimeoutError:
                result = {"url": None, "analysis": {"verdict": "error", "reasoning": "Timeout"}, "malicious": False}
            results.append(result)
            if result.get("malicious"):
                malicious_count += 1

    output = {
        "domain": domain,
        "total_urls": total_urls,
        "malicious_mentions": malicious_count,
        "malicious_likelihood": malicious_count / total_urls if total_urls else 0.0,
        "results": [
            {
                "url": r["url"],
                "analysis": r["analysis"]
            }
            for r in results
        ]
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)
    print(f"[+] Analysis results written to {output_path}")
