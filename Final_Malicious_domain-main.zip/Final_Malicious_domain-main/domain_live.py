import os
import dns.resolver
import json
import requests
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed

def valid_requests(domain, timeout=3):
    headers = {"User-Agent": "Mozilla/5.0 (compatible; URLChecker/1.0; +https://example.com/bot)"}
    try:
        r = requests.get(f"http://{domain}", headers=headers, timeout=timeout, allow_redirects=True, verify=False)
        if r.status_code == 200:
            return True
        return False
    except Exception as e:
        return False


def resolve_domains(domain_list, max_workers=50):
    resolving = []
    not_resolving = []

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(valid_requests, domain): domain for domain in domain_list}
        for future in tqdm(as_completed(futures), total=len(futures), desc="Initial domain resolution"):
            domain = futures[future]
            is_valid = future.result()
            if is_valid:
                resolving.append(domain)
            else:
                not_resolving.append(domain)

    return resolving, not_resolving


def check_live_domains(domain, domain_list, is_low):
    output_path = f'outputs/alive_domains_{"low" if is_low else "high"}_{domain}.json'

    if os.path.exists(output_path):
        with open(output_path, 'r', encoding='utf-8') as f:
            return json.load(f)

    results = {'resolving': [], 'not_resolving': []}

    # Step 1: Resolve A records directly
    initial_resolving, unresolved = resolve_domains(domain_list)

    # Merge results
    results['resolving'] = list(set((initial_resolving)))
    results['not_resolving'] = list(set(unresolved))

    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2)

    return results

"""
with open('low_conf_domains.txt', 'r') as file:
    low_conf_domains = file.readlines()
    low_conf_domains = [d.replace('\n', '') for d in low_conf_domains]

check_live_domains('pnc.com', low_conf_domains, is_low=True)
"""

