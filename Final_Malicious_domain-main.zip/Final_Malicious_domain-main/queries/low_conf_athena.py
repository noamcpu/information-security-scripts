import json
import os
import pandas as pd
from queries.athena import query_athena, order_query_result
from concurrent.futures import ProcessPoolExecutor, as_completed

def extract_unique_values(data, generic_keywords=None):
    if generic_keywords is None:
        generic_keywords = [
            "privacy", "proxy", "protected", "whoisguard", "domainsbyproxy", "unavailable", "whois",
            "redacted", "censored", "obfuscated", "contact@privacy", "anonymous", "masked",
            "activation", "no-reply", "service", "reactivation", "recovery", "private", "sale", "registration", 'N/A'
        ]
    generic_keywords = set(generic_keywords)  # Convert to set for O(1) lookups

    def is_clean(val):
        val = val.lower()
        return len(val) >= 2 and not any(g in val for g in generic_keywords)

    company_names = set()
    registrant_names = set()
    emails = set()
    phones = set()

    for r in data:
        company = r.get("registrant_company")
        if isinstance(company, str) and is_clean(company):
            company_names.add(company)
        registrant = r.get("registrant_name")
        if isinstance(registrant, str) and is_clean(registrant):
            registrant_names.add(registrant)
        email = r.get("registrant_email")
        if isinstance(email, str) and is_clean(email) and '@' in email:
            emails.add(email)
        phone = r.get("registrant_phone")
        if isinstance(phone, str) and is_clean(phone):
            phones.add(phone)

    return {
        "company_names": list(company_names),
        "registrant_names": list(registrant_names),
        "emails": list(emails),
        "phones": list(phones),
    }

def query_parallel(values, threshold, max_batch_size=25):
    selected = """
        domain_name,
        create_date,
        expiry_date,
        domain_registrar_name,
        registrant_name,
        registrant_company,
        registrant_email,
        registrant_phone,
        administrative_name,
        administrative_company,
        administrative_email,
        administrative_phone,
        technical_name,
        technical_company,
        technical_email,
        technical_phone,
        billing_name,
        billing_company,
        billing_email,
        billing_phone
    """

    queries = []
    def safe_in_clause(items):
        items = [i for i in items if "'" not in i]
        return f"({','.join([f'\'{i}\'' for i in items])})"

    # Batch IN clauses to avoid large query issues
    for field, alias, items in [
        ("registrant_company", "company_names", values["company_names"]),
        ("registrant_name", "registrant_names", values["registrant_names"]),
        ("registrant_email", "emails", values["emails"]),
        ("registrant_phone", "phones", values["phones"]),
    ]:
        if not items:
            continue
        for i in range(0, len(items), max_batch_size):
            batch = items[i:i + max_batch_size]
            in_clause = safe_in_clause(batch)
            query = f"""
                SELECT {selected}
                FROM silver_db.bucketed_whois_data
                WHERE {field} IN {in_clause}
                  AND expiry_date IS NOT NULL
                LIMIT {threshold + 1}
            """
            queries.append((query, alias))

    if not queries:
        return None

    results = []
    with ProcessPoolExecutor(max_workers=min(len(queries), 8)) as executor:  # Reduced workers for processes
        future_to_query = {executor.submit(query_athena, q): alias for q, alias in queries}
        for future in as_completed(future_to_query):
            try:
                df = future.result()
                if df is not None and not df.empty:
                    df['source_field'] = future_to_query[future]  # Track source field
                    results.append(df)
            except Exception as e:
                print(f"Query failed for {future_to_query[future]}: {e}")

    if not results:
        return None

    return pd.concat(results, ignore_index=True)


def validate_unique_values(domain):
    output_file = f"outputs/low_confidence_{domain}.json"
    if os.path.exists(output_file):
        with open(output_file) as f:
            return json.load(f)

    with open(f"outputs/high_confidence_{domain}.json") as f:
        high_conf = json.load(f)

    if not high_conf:
        with open(output_file, "w") as f:
            json.dump([], f)
        return []

    threshold = len(high_conf) * 5
    values = extract_unique_values(high_conf)
    df = query_parallel(values, threshold)

        # ---------- 1)  ensure date columns are datetime ----------
    df["expiry_date_str"] = df["expiry_date"]
    df["expiry_date"] = pd.to_datetime(df["expiry_date"], errors="coerce")

    # ---------- 2)  counts: one per domain per indicator ----------
    def domain_counts(ind_col, set_name):
        """Return {indicator_value: #distinct domains} limited to wanted values."""
        subset = df[df[ind_col].isin(values[set_name])]
        subset = subset.drop_duplicates(subset=["domain_name", ind_col])
        return subset.groupby(ind_col)["domain_name"].nunique()

    count_maps = {
        "company_names"    : domain_counts("registrant_company", "company_names"),
        "registrant_names" : domain_counts("registrant_name",   "registrant_names"),
        "emails"           : domain_counts("registrant_email",  "emails"),
        "phones"           : domain_counts("registrant_phone",  "phones"),
    }

    # ---------- 3)  which indicator values are truly “unique”? ----------
    unique_vals = {
        k: {val for val, n in s.items() if n < threshold}
        for k, s in count_maps.items()
    }

    # ---------- 4)  every domain that ever had ≥1 unique indicator ----------
    mask = (
        df["registrant_company"].isin(unique_vals["company_names"])   |
        df["registrant_name"].isin(unique_vals["registrant_names"])   |
        df["registrant_email"].isin(unique_vals["emails"])            |
        df["registrant_phone"].isin(unique_vals["phones"])
    )
    matching_domains = set(df.loc[mask, "domain_name"])

    # ---------- 5)  keep the most‑recent, un‑expired row for each domain ----------
    df = (
        df[(df["domain_name"].isin(matching_domains)) &
        (df["expiry_date"].notna()) &
        (df["expiry_date"] >= pd.Timestamp.now().normalize())]
    )

    # restore expirty date to the original format
    df["expiry_date"] = df["expiry_date_str"]

    df = order_query_result(df)

    # Remove emails containing @<domain>
    domain_pattern = f"@{domain}"
    df = df[~df["registrant_email"].str.contains(domain_pattern, na=False)]

    # Deduplicate by most complete record
    df["non_empty_count"] = df.apply(lambda r: r.notna() & (r != ""), axis=1).sum(axis=1)
    df = df.sort_values(["domain_name", "non_empty_count"], ascending=[True, False])
    df = df.drop_duplicates(subset="domain_name", keep="first").drop(columns=["non_empty_count", "source_field"])

    df.to_json(output_file, orient="records")

    return df.to_dict(orient="records")

'''
if __name__ == "__main__":
    validate_unique_values('cyberark.com')
'''