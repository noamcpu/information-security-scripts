from googleapiclient.discovery import build
from googlesearch import search
from urllib.parse import urlparse
import concurrent.futures

def normalize_domain(text):
    if not text:
        return ""
    patterns = [
        ('[.]', '.'), ('(.)', '.'), ('{.}', '.'),
        ('[dot]', '.'), ('(dot)', '.'), ('{dot}', '.'),
        ('\\[.\\]', '.'), ('\\[dot\\]', '.'),
        ('[@]', '@'), ('\\[@\\]', '@'),
        (' dot ', '.'),
        ('\\[\\.]', '.'),
    ]
    result = text.lower()
    for pattern, replacement in patterns:
        result = result.replace(pattern, replacement)
    return result

def is_valid_url(url, domain):
    try:
        parsed = urlparse(url)
        if contains_domain(url, domain):
            return True
        return bool(parsed.netloc) and domain not in parsed.netloc.lower()
    except:
        return False
    
def contains_domain(text, domain):
    if not text:
        return False
    normalized_domain = normalize_domain(domain)
    normalized_text = normalize_domain(text.lower())
    if normalized_domain in normalized_text:
        return True
    obfuscations = [
        domain.replace('.', '[.]'),
        domain.replace('.', '(.)'),
        domain.replace('.', '{.}'),
        domain.replace('.', '[dot]'),
        domain.replace('.', '(dot)'),
        domain.replace('.', '{dot}'),
        domain.replace('.', ' dot '),
    ]
    for obf in obfuscations:
        if obf in text.lower():
            return True
    return False


def search_query_block(query, state):
    print(f"[*] Using search query: {query}")
    try:
        scrape_urls = google_scrape_search(query, state)
        new_urls = set(scrape_urls) - state['found_links']
        if new_urls:
            with state['found_links_lock']:
                state['found_links'].update(new_urls)
            with state['results_lock']:
                for url in new_urls:
                    state['results'].append({
                        "referring_site": url,
                        "title": "N/A (googlesearch)",
                        "snippet": "N/A (googlesearch)",
                        "source": "scrape",
                        "query": query,
                        "links_found": []
                    })

        if state['api_key']:
            num_api_calls = (state['pages'] + 9) // 10
            api_tasks = []
            with concurrent.futures.ThreadPoolExecutor(max_workers=min(num_api_calls, state['max_threads'])) as executor:
                for i in range(num_api_calls):
                    start_index = i * 10 + 1
                    api_tasks.append(executor.submit(process_api_results, query, state, start_index))

                for future in concurrent.futures.as_completed(api_tasks):
                    api_results = future.result()
                    api_new_urls = [r["referring_site"] for r in api_results if r["referring_site"] not in state['found_links']]
                    if api_new_urls:
                        with state['found_links_lock']:
                            state['found_links'].update(api_new_urls)
                        with state['results_lock']:
                            for result in api_results:
                                if result["referring_site"] in api_new_urls:
                                    state['results'].append(result)
    except Exception as e:
        print(f"[!] Error in query block '{query}': {e}")

def google_api_search(query, state, start_index=1):
    if not state['api_key'] or not state['cse_id']:
        return []
    try:
        service = build("customsearch", "v1", developerKey=state['api_key'])
        result = service.cse().list(
            q=query,
            cx=state['cse_id'],
            start=start_index,
            num=10
        ).execute()
        
        return result.get('items', [])
    except Exception as e:
        print(f"[!] API Search Error: {str(e)}")
        return []

def google_scrape_search(query, state):
    try:
        search_results = search(query, num_results=state['pages'])
        urls = []
        for url in search_results:
            if is_valid_url(url, state['domain']):
                urls.append(url)
        return urls
    except Exception as e:
        print(f"[!] googlesearch Error: {str(e)}")
        return []

def search_google(state):
    print(f"[*] Searching for websites mentioning {state['domain']}...")        
    obfuscated_variations = [
        state['domain'].replace('.', '[.]'),
        state['domain'].replace('.', '(.)'),
        state['domain'].replace('.', '[dot]'),
        state['domain'].replace('.', '(dot)')
    ]
    
    search_queries = [
        f'inurl:{state["domain"]}',
        f'inurl'
        f'"{state["domain"]}"',
        f'intext:"{state["domain"]}"',
        f'"{state["domain"]}" -inurl:{state["domain"]}',
        f'intitle:{state["domain"]}',
        *[f'"{variation}"' for variation in obfuscated_variations],
        *[f'intext:"{variation}"' for variation in obfuscated_variations],
    ]

    with concurrent.futures.ThreadPoolExecutor(max_workers=max(state['max_threads'], 20)) as executor:
        futures = [executor.submit(search_query_block, query, state) for query in search_queries]
        concurrent.futures.wait(futures)
        
    all_urls = [r['referring_site'] for r in state['results']]
        
    print(f"[+] Found {len(all_urls)} potential websites to check")
    return all_urls

def process_api_results(query, state, start_index):
    results = google_api_search(query, state, start_index)
    processed_results = []
    for item in results:
        url = item.get('link')
        if is_valid_url(url, state['domain']):
            processed_results.append({
                "referring_site": url,
                "title": item.get('title', ''),
                "snippet": item.get('snippet', ''),
                "source": "api",
                "query": query,
                "links_found": []
            })
    return processed_results
