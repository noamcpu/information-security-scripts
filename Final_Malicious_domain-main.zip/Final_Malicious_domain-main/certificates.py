import json
import os
import socket
import ssl
from OpenSSL import crypto
from datetime import datetime
import concurrent.futures

def save_to_json(data, output_path):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def get_certificate_data(domain):
    try:
        context = ssl.create_default_context()
        with socket.create_connection((domain, 443), timeout=2) as sock:
            with context.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = crypto.load_certificate(
                    crypto.FILETYPE_ASN1,
                    ssock.getpeercert(binary_form=True)
                )

        issuer = cert.get_issuer()
        subject = cert.get_subject()
        not_before = datetime.strptime(cert.get_notBefore().decode('ascii'), "%Y%m%d%H%M%SZ")
        not_after = datetime.strptime(cert.get_notAfter().decode('ascii'), "%Y%m%d%H%M%SZ")

        return {
            "found": True,
            "domain": domain,
            "issuer": getattr(issuer, "O", None),
            "not_before": not_before,
            "not_after": not_after,
            "self_signed": getattr(issuer, "CN", None) == getattr(subject, "CN", None)
        }
    except Exception as e:
        return {
            "found": False,
            "domain": domain,
            "error": str(e)
        }

def analyze_domain_certificates(domain, high_conf_domains, low_conf_domains):
    output_path = f"certificates/diffs_{domain}.json"

    if os.path.exists(output_path):
        with open(output_path, 'r', encoding='utf-8') as f:
            return json.load(f)

    # Step 1: Batch fetch certificates for all domains
    all_domains = set(high_conf_domains).union(low_conf_domains)
    cert_data_map = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        future_to_domain = {executor.submit(get_certificate_data, dom): dom for dom in all_domains}
        for future in concurrent.futures.as_completed(future_to_domain):
            cert_data_map[future_to_domain[future]] = future.result()

    # Define common validity periods globally
    common_periods = [30, 90, 180, 365, 730]

    # Step 2: Aggregate high-confidence certificate stats
    high_conf_issuers = set()
    high_conf_validity_periods = set()
    for dom in high_conf_domains:
        cert_data = cert_data_map.get(dom, {})
        if cert_data.get("found"):
            if cert_data["issuer"]:
                high_conf_issuers.add(cert_data["issuer"])
            duration_days = (cert_data["not_after"] - cert_data["not_before"]).days
            duration_days = min(common_periods, key=lambda x: abs(x - duration_days))
            high_conf_validity_periods.add(duration_days)

    print(f"high conf issuers: {high_conf_issuers}")
    print(f"high conf validity periods: {high_conf_validity_periods}")

    # Step 3: Analyze low-confidence domains
    results = []
    for low_domain in low_conf_domains:
        cert_data = cert_data_map.get(low_domain, {})
        if not cert_data.get("found", False):
            continue

        result = {
            "domain": low_domain,
            "issuer": cert_data["issuer"],
            "issuer_match": False,
            "validity_match": False,
            "self_signed": cert_data["self_signed"]
        }

        # Check issuer match
        result["issuer_match"] = cert_data["issuer"] in high_conf_issuers

        # Check validity period
        duration_days = (cert_data["not_after"] - cert_data["not_before"]).days
        duration_days = min(common_periods, key=lambda x: abs(x - duration_days))
        result["validity_match"] = duration_days in high_conf_validity_periods

        # Mark as malicious if anything mismatched
        if not result["issuer_match"] or not result["validity_match"] or result["self_signed"]:
            results.append(result)

    # Step 4: Save only malicious domains
    save_to_json(results, output_path)
    return results
