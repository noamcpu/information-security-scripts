import json
import os
import dns.resolver
import requests
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import concurrent.futures
from queries.athena import get_ip_info

def save_to_json(data, output_path):
    """Save data to JSON file with proper encoding."""
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def batch_get_ip_addresses(domains, max_workers=100):
    """Resolve IPs for unique domains in a single batch."""
    resolver = dns.resolver.Resolver()
    resolver.timeout = 1
    resolver.lifetime = 1

    def resolve_domain(domain):
        try:
            result = resolver.resolve(domain, 'A')
            return domain, [ip.to_text() for ip in result]
        except Exception:
            return domain, []

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        results = list(executor.map(resolve_domain, domains))
    return {domain: ips for domain, ips in results}

def batch_get_country_codes(ips, max_workers=5):
    """Fetch country codes for unique IPs in a single batch."""
    if not ips:
        return {}

    session = requests.Session()
    base_url = "https://api.iplocation.net/?ip="
    country_cache = {}

    def fetch_country(ip):
        if ip in country_cache:
            return ip, country_cache[ip]
        try:
            resp = session.get(f"{base_url}{ip}", timeout=2)
            if resp.status_code == 200:
                data = resp.json()
                country = data.get("country_code2")
                if country:
                    country_cache[ip] = country
                    return ip, country
        except Exception:
            pass
        return ip, None

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        results = list(executor.map(fetch_country, ips))
    return dict(results)

def analyze_domain_ips(low_conf_domain, target_ip_data, high_conf_stats):
    result = {
        "low_conf_domain": low_conf_domain,
        "ips": [],
        "diffs": {}
    }

    try:
        # Check if target domain has IPs
        if not target_ip_data:
            result["error"] = "No IPs resolved for target domain"
            return result

        # Format target domain data
        result["ips"] = [
            {"ip": ip, **info} for ip, info in target_ip_data.items()
        ]

        # Aggregate target stats
        target_stats = {
            "ips": set(ip["ip"] for ip in result["ips"]),
            "asn": set(ip["asn"] for ip in result["ips"] if ip.get("asn")),
            "isp": set(ip["isp"] for ip in result["ips"] if ip.get("isp")),
            "type": set(ip["type"] for ip in result["ips"] if ip.get("type")),
            "country": set(ip["country"] for ip in result["ips"] if ip.get("country"))
        }

        # Compare against high_conf_stats
        for key in ["asn", "isp", "type", "country"]:
            target_set = target_stats[key]
            high_conf_set = high_conf_stats.get(key, set())
            is_different = bool(target_set and high_conf_set and not target_set.issubset(high_conf_set))
            if is_different:
                result["diffs"][key] = {
                    "target_" + key: list(target_set),
                    "high_conf_" + key: list(high_conf_set)
                }

        return result

    except Exception as e:
        result["error"] = str(e)
        return result

def compare_ips_and_write_diffs(domain, low_conf_domains, high_conf_domains, max_workers=20):
    output_file = f"ips/diffs_{domain}.json"
    if os.path.exists(output_file):
        with open(output_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    domains = set(low_conf_domains).union(high_conf_domains)

    domain_ips = batch_get_ip_addresses(domains)

    all_ips = list({ip for ips in domain_ips.values() for ip in ips})

    # Fetch IP metadata and country codes
    all_ip_info = get_ip_info(all_ips) if all_ips else {}
    country_codes = batch_get_country_codes(all_ips) if all_ips else {}
    for ip in all_ip_info:
        all_ip_info[ip]["country"] = country_codes.get(ip)

    # Create IP data maps
    domain_ip_data = {
        dom: {ip: all_ip_info[ip] for ip in ips if ip in all_ip_info}
        for dom, ips in domain_ips.items()
    }

    # Aggregate high_conf_stats
    high_conf_stats = {
        "ips": set(),
        "asn": set(),
        "isp": set(),
        "type": set(),
        "country": set()
    }
    for dom in high_conf_domains:
        ip_data = domain_ip_data.get(dom, {})
        high_conf_stats["ips"].update(ip for ip in ip_data.keys())
        for info in ip_data.values():
            for key in ["asn", "isp", "type", "country"]:
                if info.get(key):
                    high_conf_stats[key].add(info[key])

    # Analyze low_conf_domains
    results = []
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        futures = [
            executor.submit(
                analyze_domain_ips,
                low_domain,
                domain_ip_data.get(low_domain, {}),
                high_conf_stats
            )
            for low_domain in low_conf_domains
        ]
        concurrent.futures.wait(futures)
        results.extend(f.result() for f in futures)

    # Collect domains with differences
    malicious_domains = [
        result for result in results
        if "diffs" in result and result["diffs"]
    ]

    # Write results to output file
    if malicious_domains:
        save_to_json(malicious_domains, output_file)
    
    return malicious_domains
