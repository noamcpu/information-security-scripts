
import json
import os
import pandas as pd
from queries.firebolt_queries import execute_query
from queries.athena import order_query_result
import tldextract
from concurrent.futures import ThreadPoolExecutor

domain_len_threshold = 7

def domains_by_company_name(name_list):
    query_parts = []
    for i, word in enumerate(name_list, 1):
        part = f"""SELECT {i} as pos, domain, word_number, start_position 
            FROM whois_domains_ngrams 
            WHERE n_gram = '{word}'"""
        query_parts.append(part)

    whois_query = " UNION ".join(query_parts)

    query = f"""
        WITH whois_domains_ngrams_search AS (
        {whois_query}
        ), whois_domains_ngrams_win AS (
        SELECT RANK() OVER(PARTITION BY domain ORDER BY pos) r_id, RANK() OVER(PARTITION BY domain ORDER BY word_number, start_position) word_pos, pos, domain, word_number, start_position
        FROM whois_domains_ngrams_search
        )
        SELECT DISTINCT
                domain_name,
                create_date,
                expiry_date,
                domain_registrar_name,
                registrant_name,
                registrant_company,
                registrant_email,
                registrant_phone,
                administrative_name,
                administrative_company,
                administrative_email,
                administrative_phone,
                technical_name,
                technical_company,
                technical_email,
                technical_phone,
                billing_name,
                billing_company,
                billing_email,
                billing_phone
        FROM "whois_data_v"
        WHERE domain IN (
                        SELECT domain
                        FROM whois_domains_ngrams_win
                        WHERE (r_id = {len(name_list)} AND r_id = word_pos))
        AND TRY_CAST(expiry_date AS DATE) > CURRENT_DATE
    """
    rows = execute_query(query)
    columns = [
        "domain_name", "create_date", "expiry_date", "domain_registrar_name",
        "registrant_name", "registrant_company", "registrant_email", "registrant_phone",
        "administrative_name", "administrative_company", "administrative_email", "administrative_phone",
        "technical_name", "technical_company", "technical_email", "technical_phone",
        "billing_name", "billing_company", "billing_email", "billing_phone"
    ]
    df = pd.DataFrame(rows, columns=columns)
    if len(name_list) == 1 and len(name_list[0]) < domain_len_threshold:
        pattern = f'(^{name_list[0]}$|^{name_list[0]}-|-{name_list[0]}$|-{name_list[0]}-)'
        df['matches'] = df['domain_name'].str.extract(pattern)  
        df = df[df['matches'].notna()]
        df = df.drop('matches', axis=1)
    return df

def domains_by_domain_name(domain):
    domain_name = tldextract.extract(domain).domain
    query = f"""
    SELECT DISTINCT
                domain_name,
                create_date,
                expiry_date,
                domain_registrar_name,
                registrant_name,
                registrant_company,
                registrant_email,
                registrant_phone,
                administrative_name,
                administrative_company,
                administrative_email,
                administrative_phone,
                technical_name,
                technical_company,
                technical_email,
                technical_phone,
                billing_name,
                billing_company,
                billing_email,
                billing_phone
        FROM "whois_data_v"
        WHERE domain IN (
                SELECT domain 
                FROM whois_domains_ngrams 
                WHERE n_gram = '{domain_name}'
            )
        AND TRY_CAST(expiry_date AS DATE) > CURRENT_DATE            
        """
    rows = execute_query(query)
    columns = [
        "domain_name", "create_date", "expiry_date", "domain_registrar_name",
        "registrant_name", "registrant_company", "registrant_email", "registrant_phone",
        "administrative_name", "administrative_company", "administrative_email", "administrative_phone",
        "technical_name", "technical_company", "technical_email", "technical_phone",
        "billing_name", "billing_company", "billing_email", "billing_phone"
    ]
    df = pd.DataFrame(rows, columns=columns)
    # filtering only if domain len is short
    if len(domain_name) < domain_len_threshold:
        pattern = f'(^{domain_name}$|^{domain_name}-|-{domain_name}$|-{domain_name}-)'
        df['matches'] = df['domain_name'].str.extract(pattern)  
        df = df[df['matches'].notna()]
        df = df.drop('matches', axis=1)
    return df

def get_similar_domain_name(name_list, domain):
    output_path = f"outputs/similar_domain_{domain}.json"
    if os.path.exists(output_path):
        with open(output_path, 'r', encoding='utf-8') as file:
            return json.load(file)
        
    print(f"domain name list for similar domain is: {name_list}")
    # Create tasks for parallel execution
    with ThreadPoolExecutor(max_workers=2) as executor:
        df_name_future = executor.submit(domains_by_company_name, name_list)
        df_domain_future = None
        # Only create second task if needed
        if not (len(name_list) == 1 and '.' + name_list[0] + '.' in '.' + domain):
            df_domain_future = executor.submit(domains_by_domain_name, domain)

    # Get results
    df_name = df_name_future.result()
    if df_domain_future:
        df_domain = df_domain_future.result()
        df = pd.concat([df_name, df_domain], ignore_index=True).drop_duplicates()
    else:
        df = df_name

    df = order_query_result(df)

    def count_meaningful(row):
        # Count non-empty strings (exclude "" and NaN)
        return sum(1 for val in row if isinstance(val, str) and val.strip() != "")

    # Add temporary columns for sorting
    df = df.assign(
        non_null_count=df.notna().sum(axis=1),
        meaningful_count=df.apply(count_meaningful, axis=1)
    ).sort_values(
        ['meaningful_count', 'non_null_count'], ascending=[False, False]
    ).drop_duplicates(
        subset=['domain_name', 'create_date', 'expiry_date'], keep='first'
    ).drop(
        ['non_null_count', 'meaningful_count'], axis=1
    )

    df.to_json(output_path, orient="records", indent=2)
    return json.loads(df.to_json(orient="records"))


#print(get_similar_domain_name(['pnc'], 'pnc.com'))
#print(domains_by_domain_name('pnc.com'))