from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
import os
from firebolt.db import connect
from firebolt.client.auth import ClientCredentials
import tldextract
from asyncio import Semaphore, gather, run
from firebolt.async_db import connect as async_connect


client_id = "Y0s5x33rD16GWzJCng3AIS7OLM1CGT98"
client_secret = "eTByfcQHDA7olNR72xDMnrEqOn_QnyZjRdLOu7D6xFcb7cFuEtldLDRjujyJNVoi"

database_name = "whois_data"
engine_name = "MalantaResearch"
account_name = "malanta-ai"


def execute_query(query):
    connection = connect(engine_name=engine_name, database=database_name, account_name=account_name, auth=ClientCredentials(client_id, client_secret))
    cursor = connection.cursor()
    try:
        cursor.execute(query)
        rows = cursor.fetchall()
        print(f"query ended with {len(rows)} rows")
        return rows
    except Exception as e:
        print(f"error : {e} in firebolt for : {query}")
    finally:
        cursor.close()
        connection.close()


def execute_multiple_queries(queries):
    MAX_CONCURRENT_QUERIES = 5

    async def run_queries():
        semaphore = Semaphore(MAX_CONCURRENT_QUERIES)

        async with await async_connect(
            engine_name=engine_name,
            database=database_name,
            account_name=account_name,
            auth=ClientCredentials(client_id, client_secret),
        ) as connection:
            
            async def run_query(query):
                async with semaphore:  # Limit concurrency
                    try:
                        cursor = connection.cursor()
                        await cursor.execute(query)
                        rows = await cursor.fetchall()
                        print(f"Query ended with {len(rows)} rows")
                        return rows
                    except Exception as e:
                        print(f"Error: {e} in Firebolt for: {query}")
                        return []

            tasks = [run_query(q) for q in queries]
            return await gather(*tasks)

    results = run(run_queries())
    return [row for query_result in results for row in query_result]



def get_subdomains_data(domain, number_of_results = 30):
    if os.path.exists(f'subdomains/{domain}.txt'):
        with open(f'subdomains/{domain}.txt', 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip()][:number_of_results]
    ext = tldextract.extract(domain)
    query = f"SELECT DISTINCT fqdn from malanta_sub_domains where domain = '{ext.domain}' and suffix = '{ext.suffix}'"
    rows = execute_query(query)
    return [item for sublist in rows for item in sublist][:number_of_results] if rows else []


# ------------------ SUBDOMAINS BULK --------------------

subdomain_count = 50  # Number of subdomains to fetch per domain

def chunk_domains(domain_list, chunk_size=100):
    for i in range(0, len(domain_list), chunk_size):
        yield domain_list[i:i + chunk_size]

def process_chunk(chunk):
    os.makedirs("subdomains", exist_ok=True)

    extracted = [tldextract.extract(domain) for domain in chunk]
    unique_pairs = {(e.domain, e.suffix): f"{e.domain}.{e.suffix}" for e in extracted}

    domain_rows = "\nUNION\n".join(
        [f"SELECT '{d}' AS domain, '{s}' AS suffix" for (d, s) in unique_pairs.keys()]
    )

    query = f"""
    WITH domains AS (
        {domain_rows}
    ),
    subdomains AS (
        SELECT 
            row_number() OVER (PARTITION BY sd.domain, sd.suffix) AS rn,
            sd.fqdn,
            sd.domain,
            sd.suffix
        FROM malanta_sub_domains sd
        INNER JOIN domains d ON sd.domain = d.domain AND sd.suffix = d.suffix
    )
    SELECT fqdn, domain, suffix FROM subdomains WHERE rn <= {subdomain_count}
    """

    try:
        rows = execute_query(query)
    except Exception as e:
        print(f"[ERROR] Query failed: {e}")
        rows = []
    
    # Group all subdomains (no filtering)
    grouped = defaultdict(list)
    for fqdn, domain, suffix in rows:
        key = f"{domain}.{suffix}"
        grouped[key].append(fqdn)

    # Write results (including empty files)
    for (domain, suffix), file_name in unique_pairs.items():
        path = f"subdomains/{file_name}.txt"
        with open(path, "w", encoding="utf-8") as f:
            subs = grouped.get(file_name, [])
            for sub in subs:
                f.write(sub + "\n")

def write_domains_bulk(domains):
    
    domain_strings = [
        d["domain"] if isinstance(d, dict) else d
        for d in domains
        if isinstance(d, (dict, str))
    ]
    domain_strings = [
        domain for domain in domain_strings
        if not os.path.exists(f"subdomains/{domain}.txt")
    ]

    chunked = list(chunk_domains(domain_strings, 100))
    max_workers = 15

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(process_chunk, chunk) for chunk in chunked]
        for future in futures:
            future.result()
