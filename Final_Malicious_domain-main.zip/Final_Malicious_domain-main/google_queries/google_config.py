import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import threading

DEFAULT_PAGES = 5
DEFAULT_DELAY = 1
DEFAULT_MAX_THREADS = 50
DEFAULT_MAX_BODY = 5000
DEFAULT_MAX_HEADERS = 10
DEFAULT_MAX_TOKENS = 5000

def create_scanner_state(domain, pages=DEFAULT_PAGES, output=None, delay=DEFAULT_DELAY, max_threads=DEFAULT_MAX_THREADS):
    session = requests.Session()
    retries = Retry(total=3, backoff_factor=0.5, status_forcelist=[429, 500, 502, 503, 504])
    session.mount('https://', HTTPAdapter(max_retries=retries))
    
    return {
        'domain': domain.lower(),
        'pages': pages,
        'output_file': output,
        'delay': delay,
        'results': [],
        'found_links': set(),
        'max_threads': max_threads,
        'results_lock': threading.Lock(),
        'found_links_lock': threading.Lock(),
        'api_key': "AIzaSyCpb_HxbQLexEL6AhjEGNIuepp6PnnbH1Y",
        'cse_id': "b22dc9f27aeb34865",
        'session': session,
        'headers': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
    }
