import json
import os
from concurrent.futures import ThreadPoolExecutor, as_completed

parking_keywords = [
    "buy this domain", "this domain is for sale", "domain for sale", "forsale-lander", "gdforsale",
    "this domain is now reserved", "sedo parking", "parked domain", "parking service",
    "this website is for sale", "skenzo.com/sk-privacy.php", "aftermarket domain",
    "domain reseller", "available for purchase", "domain details page", "www.webnames.ru",
    "get this domain", "purchase this domain", "domain available", "marketplace-domain-details",
    "sports cars lifestyle celebs travel business finances", "premium domain for sale",
    "this domain is listed for sale", "sedo domain parking", "contact us to buy this domain",
    "lease this domain", "bid on this domain", "this domain is on auction", "domain auction listing",
    "this domain is monetized", "monetized domain page", "domain owned by a third party",
    "disclaimer: sedo maintains no relationship with third party advertisers", "click here to buy",
    "interested in this domain?", "domain marketplace", "inquire about this domain", "exclusive domain sale",
    "domain inquiry form", "domain parked free of charge", "let possiblearguments =",
    "flippa domain listing", "brandbucket premium domain", "domainprice",
    "this domain name is currently for sale on", "godaddy domain marketplace", "hugedomains.com",
    "adsdeli - domain - landingpage", "squadhelp domain for sale", "uniregistry market",
    "dan.com buy now", "is for sale", "epik domain marketplace", "name.com premium domain",
    "sedo domain resale", "afternic fast transfer", "brandpa domain sale", "domain at snapnames",
    "sav.com domain auction", "brandable domain available", "convert phone number to short url",
    "purchased through escrow", "class=\"reg-text\">this domain is registered at <a href",
    "this site is parked", "coming soon", "this page is under construction",
    "register your favorite .vg domain name", "future home of", "temporary site",
    "site is being developed", "by submitting and clicking get price",
    "hosted by sedo", "site powered by parked.com", "your domain is active", "get your .vg domain today",
    "default cpanel page", "nginx default server page", "parking-lander",
    "domain may be available for registration", "apache2 ubuntu default page",
    "web hosting service placeholder", "call our award-winning sales & support team",
    "domain setup complete", "this website is offline", "site is unavailable",
    "<html><head><title></title><meta name=\"revised\" content=\"1.1.7\" /></head><body></body></html>",
    ".website.ws/wc_landing.dhtml?domain=", "heroku | application error", "<script>window.park =",
    "all you have to do now is upload your website files", "Happy to see your domain with Hostinger",
    "<link rel=\"pingback\"little.im/xmlrpc.php", "<title>subdomain.com - subdomain.com</title>",
    "cloudfront.net/themes/assets/star", "site temporarily closed", "is for sale!",
    "https://www.godaddy.com/forsale", "the simple, and safe way to buy domain names", "get this domain",
    "let this space go to waste", "Activate my site", r"www.names.co.uk/parked-domains"
]

def get_parked_domains(domain_list):
    domain_list = list(set(domain_list))  # Remove duplicates
    results = []

    def check_domain(domain):
        path = f'html/{domain}_html.json'
        if not os.path.exists(path):
            return None

        try:
            with open(path, 'r', encoding='utf-8') as file:
                html = json.load(file)
        except Exception:
            return None

        content = (html.get('title', '') or '') + (html.get('body_text', '') or '')
        content = content.lower()

        if not content:
            return None

        for keyword in parking_keywords:
            if keyword in content:
                return domain

        return None

    with ThreadPoolExecutor(max_workers=10) as executor:
        future_to_domain = {executor.submit(check_domain, domain): domain for domain in domain_list}
        for future in as_completed(future_to_domain):
            result = future.result()
            if result:
                results.append(result)

    return results

def check_property(property, high_conf_domains, low_conf_domains):
    related = []
    found = False
    for low in low_conf_domains:
        if os.path.exists(f'html/{low}_html.json'):
            with open(f'html/{low}_html.json', 'r', encoding='utf-8') as file:
                html = json.loads(file.read())
            if property in html and html[property]:
                property_list = html[property]
                if isinstance(property_list, str):
                    property_list = [property]
                for h in property_list:
                    for high in high_conf_domains:
                        if ('/' + high + '/' in h + '/') or ('.' + high + '/' in h + '/'):
                            related.append(low)
                            found = True
                            break
                    if found:
                        found = False
                        break
    return list(set(related))



def check_property_opposite(property, high_conf_domains, low_conf_domains):
    related = []
    found = False
    for high in high_conf_domains:
        if os.path.exists(f'html/{high}_html.json'):
            with open(f'html/{high}_html.json', 'r', encoding='utf-8') as file:
                html = json.loads(file.read())
            if property in html and html[property]:
                property_list = html[property]
                if isinstance(property_list, str):
                    property_list = [property]
                for h in property_list:
                    for low in low_conf_domains:
                        if ('/' + low + '/' in h + '/') or ('.' + low + '/' in h + '/'):
                            related.append(low)
                            found = True
                            break
                    if found:
                        found = False
                        break
    return list(set(related))


def domain_connections(high_conf_domains, low_conf_domains):
    results = {}
    parked_domains = get_parked_domains(low_conf_domains)
    low_conf_domains = [domain for domain in low_conf_domains if domain not in parked_domains]
    redirect_domains = check_property('redirect_chain', high_conf_domains, low_conf_domains)
    href_domains = check_property('hrefs', high_conf_domains, low_conf_domains)
    favicon_domains = check_property('favicon', high_conf_domains, low_conf_domains)

    for r in redirect_domains:
        results[r] = results.get(r, set()) | {"redirect to known domain"}
    for h in href_domains:
        results[h] = results.get(h, set()) | {"href to known domain"}
    for f in favicon_domains:
        results[f] = results.get(f, set()) | {"favicon to known domain"}

    results = {k: list(v) for k, v in results.items()}
    print(f"finished checking {len(low_conf_domains)} domain reputation with {results}")
    return results


def domain_connections_opposite(high_conf_domains, low_conf_domains):
    results = {}
    parked_domains = get_parked_domains(high_conf_domains)
    high_conf_domains = [domain for domain in high_conf_domains if domain not in parked_domains]
    redirect_domains = check_property_opposite('redirect_chain', high_conf_domains, low_conf_domains)
    href_domains = check_property_opposite('hrefs', high_conf_domains, low_conf_domains)
    favicon_domains = check_property_opposite('favicon', high_conf_domains, low_conf_domains)

    for r in redirect_domains:
        results[r] = results.get(r, set()) | {"redirect from known domain"}
    for h in href_domains:
        results[h] = results.get(h, set()) | {"href from known domain"}
    for f in favicon_domains:
        results[f] = results.get(f, set()) | {"favicon from known domain"}

    results = {k: list(v) for k, v in results.items()}
    print(f"finished checking {len(low_conf_domains)} domain reputation with {results}")
    return results



