from urllib.parse import urljoin, quote
from bs4 import BeautifulSoup
from .google_search import contains_domain, normalize_domain
import concurrent.futures
import re
import time 
import requests

def extract_html_data(soup, response_url):
    data = {
        "title": None,
        "headers": [],
        "body_text": None,
        "hrefs": [],
        "redirect_chain": []
    }
    title_tag = soup.find("title")
    data["title"] = title_tag.get_text(strip=True) if title_tag else None
    for i in range(1, 7):
        for tag in soup.find_all(f"h{i}"):
            text = tag.get_text(strip=True)
            if text:
                data["headers"].append(text)
    hrefs = set()
    for link in soup.select('a[href], img[src], script[src], iframe[src], embed[src], source[src], link[href]'):  # Use CSS selector for efficiency
        if link.name == 'a' or link.name == 'link':
            href = link.get('href')
            if href:
                try:
                    full_url = urljoin(response_url, href)
                    hrefs.add(full_url)
                except:
                    continue
        else:
            src = link.get('src')
            if src:
                try:
                    full_url = urljoin(response_url, src)
                    hrefs.add(full_url)
                except:
                    continue
    data["hrefs"] = list(hrefs)
    body = soup.find("body")
    data["body_text"] = body.get_text(separator=" ", strip=True) if body else None
    return data

def check_single_url(result, state):
    try:
        print(f"[*] Checking: {result['referring_site']}")
    
        if contains_domain(result['referring_site'], state['domain']):
            mentions_found = [f"URL contains domain: {result['referring_site']}"]
            with state['found_links_lock']:
                state['found_links'].add(f"Domain in URL: {result['referring_site']}")
        else:
            mentions_found = []

        title = result.get('title', '')
        snippet = result.get('snippet', '')
        
        if contains_domain(title, state['domain']):
            mentions_found.append(f"Title mention: {title}")
            with state['found_links_lock']:
                state['found_links'].add(f"Title: {title}")
        
        if contains_domain(snippet, state['domain']):
            mentions_found.append(f"Snippet mention: {snippet}")
            with state['found_links_lock']:
                state['found_links'].add(f"Snippet: {snippet}")
        
        try:
            response = state['session'].get(result['referring_site'], headers=state['headers'], timeout=5)
            response.encoding = 'utf-8'
        except requests.exceptions.RequestException as e:
            print(f"[!] Error accessing {result['referring_site']}: {str(e)}")
            if mentions_found:
                with state['results_lock']:
                    result['links_found'] = mentions_found
            return
        
        if response.status_code == 200:
            try:
                soup = BeautifulSoup(response.text, 'html.parser')
                full_html = response.text.lower()                   
                html_data = extract_html_data(soup, response.url)
                result['html_data'] = html_data                   
                result['html_content'] = html_data['body_text']
                result['raw_html'] = full_html
                
                domain_mentions = {}
                
                links = soup.find_all('a', href=True)
                for link in links:
                    href = link.get('href', '').lower()
                    if state['domain'] in href:
                        domain_mentions[href] = 'href link'
                        state['found_links'].add(href)
                
                for tag in soup.find_all(['img', 'script', 'iframe', 'embed', 'source', 'link'], src=True):
                    src = tag.get('src', '').lower()
                    if state['domain'] in src:
                        domain_mentions[src] = f'{tag.name} src attribute'
                        state['found_links'].add(src)
                
                for tag in soup.find_all('link', href=True):
                    href = tag.get('href', '').lower()
                    if state['domain'] in href:
                        domain_mentions[href] = 'link href attribute'
                        state['found_links'].add(href)
                
                text_mentions = set()
                for string in soup.stripped_strings:
                    string_lower = string.lower()
                    if state['domain'] in string_lower:
                        idx = string_lower.find(state['domain'])
                        start = max(0, idx - 20)
                        end = min(len(string), idx + len(state['domain']) + 20)
                        context = string[start:end]
                        if context not in text_mentions:
                            text_mentions.add(context)
                            key = f"Plain text: ...{context}..."
                            domain_mentions[key] = 'text mention'
                
                data_attrs = []
                for tag in soup.find_all(True):
                    for attr_name, attr_value in tag.attrs.items():
                        if attr_name.startswith('data-') and isinstance(attr_value, str) and state['domain'] in attr_value.lower():
                            data_attrs.append(f"{attr_name}=\"{attr_value}\"")
                            domain_mentions[attr_value.lower()] = f'data attribute: {attr_name}'
                            state['found_links'].add(attr_value.lower())
                
                encoded_domain = quote(state['domain'])
                if encoded_domain in full_html:
                    domain_mentions[encoded_domain] = 'URL-encoded mention'
                    state['found_links'].add(encoded_domain)
                
                raw_html_count = full_html.count(state['domain'])
                parsed_count = len(domain_mentions)
                
                if raw_html_count > parsed_count:
                    current_position = 0
                    while True:
                        pos = full_html.find(state['domain'], current_position)
                        if pos == -1:
                            break
                            
                        start = max(0, pos - 30)
                        end = min(len(full_html), pos + len(state['domain']) + 30)
                        context = full_html[start:end].replace('\n', ' ').strip()
                        context = re.sub(r'\s+', ' ', context)
                        key = f"Raw HTML: ...{context}..."
                        
                        is_new_mention = True
                        for existing_key in domain_mentions:
                            if state['domain'] in existing_key and context in existing_key:
                                is_new_mention = False
                                break
                                
                        if is_new_mention:
                            domain_mentions[key] = 'raw HTML mention'
                            state['found_links'].add(key)
                            
                        current_position = pos + len(state['domain'])
                
                normalized_html = normalize_domain(full_html)
                if contains_domain(normalized_html, state['domain']):
                    matches = re.finditer(re.escape(normalize_domain(state['domain'])), normalized_html)
                    for match in matches:
                        start = max(0, match.start() - 30)
                        end = min(len(normalized_html), match.end() + 30)
                        context = normalized_html[start:end].replace('\n', ' ').strip()
                        context = re.sub(r'\s+', ' ', context)
                        key = f"Obfuscated mention: ...{context}..."
                        if key not in domain_mentions:
                            domain_mentions[key] = 'obfuscated format'
                            state['found_links'].add(key)

                mentions_list = [f"{url} ({mention_type})" for url, mention_type in domain_mentions.items()]
                mentions_list.extend(mentions_found)
                
                if mentions_list:
                    print(f"[+] Found {len(mentions_list)} mentions of {state['domain']}")
                    with state['results_lock']:
                        result['links_found'] = mentions_list
                    with state['found_links_lock']:
                        state['found_links'].update(mentions_list)
                else:
                    print(f"[-] No direct mentions found of {state['domain']}")
                    if 'snippet' in result and result['snippet'] and state['domain'] in result['snippet'].lower():
                        with state['results_lock']:
                            result['links_found'] = [f"From API snippet: {result['snippet']}"]
                        with state['found_links_lock']:
                            state['found_links'].add(result['snippet'])
            
            except Exception as e:
                print(f"[!] Error parsing content: {str(e)}")
                
        time.sleep(state['delay'])
        
    except Exception as e:
        print(f"[!] Unexpected error: {str(e)}")

def check_for_links(state):
    if not state['results']:
        print("[!] No websites found to check")
        return
    
    print(f"[*] Checking websites for mentions of {state['domain']} using up to {state['max_threads']} threads...")
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=state['max_threads']) as executor:
        futures = [executor.submit(check_single_url, result, state) for result in state['results']]
        concurrent.futures.wait(futures)
