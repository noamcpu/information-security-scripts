import json
import os
from gpt import ask_openai, analyze_images
from urllib.parse import urlparse
import concurrent.futures
from parked_filter import get_parked_domains
 
HREF_THRESHOLD = 5
GENERIC_DOMAINS = {
    'google.com', 'youtube.com', 'facebook.com', 'twitter.com', 'x.com',
    'linkedin.com', 'instagram.com', 'cloudflare.com', 'microsoft.com',
    'apple.com', 'amazon.com', 'github.com', 'wordpress.com', 'adobe.com',
    'vimeo.com', 'reddit.com', 'pinterest.com', 'whatsapp.com',
    'dropbox.com', 'googleapis.com', 'gstatic.com'
}
 
 
def save_to_json(data, output_path):
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print(f"saved html analysis of {data['domain']}!")
 
 
def gpt_analyse(low_conf_domain, high_conf_domain, html_content, domain_html, subsidiaries, company_name):
    # if html_content looks like this, return immediately
    if (
        isinstance(html_content, dict)
        and not html_content.get("title")
        and not html_content.get("body_text")
        and not html_content.get("headers")
    ):
        return {
            "category": "",
            "related": False,
            "related_reason": "No content to analyze",
            "malicious": False,
            "malicious_reason": "Not related, so not evaluated"
        }
 
    subsidiaries_html = ""
    for subsidiary in subsidiaries:
        if os.path.exists(f'html/{subsidiary}_html.json'):
            with open(f'html/{subsidiary}_html.json', 'r', encoding='utf-8') as f:
                subsidiaries_html += str(json.load(f))
    prompt = f"""
    You are a senior fraud detection and brand analyst. Your job is to detect brand-related misuse or trademark violations — even subtle ones.
 
    Evaluate a domain to determine if it is:
    1. **Related** to the company (official name: {company_name}) or its known domains: {high_conf_domain}, or subsidiaries: {subsidiaries} do not consider the domain name. (even if it same to domain comapny).
    2. **Malicious** — but only if **related**
 
    Step 1: Is the domain "RELATED"?
    Set `"related": true` if **any of the following appear in the HTML or screenshot**:
    - Brand-specific mentions of `{company_name}`, `{high_conf_domain}`, or any `{subsidiaries}`.
    - Company logo, slogan, design, or visual branding (even if modified).
    - Mentions of company products, services, locations, or teams.
    - Any design, layout, or content clearly inspired by or targeting the brand.
 
    Set `"related": false` if:
    - The page is parked, blank, under construction, or contains only default/placeholder content.
    - There is no brand-related text, visual elements, or links.
    - if domain redirected to the official company site of `{company_name}`.
 
    If `"related": false`, `"malicious"` must also be `false`.
 
    Step 2: Is the domain "MALICIOUS"? (only if related = true)
    Set `"malicious": true` only if:
    - It’s not in `{subsidiaries}` or officially associated with the company
    - AND it **actively misuses brand identity**, e.g.:
    - Fake login page, phishing attempt - only relevant for comapny! you have to find `{company_name}` in the HTML of the login page.
    - Impersonates layout or content of `{company_name}`.
    - Misleading use of name/logo in a deceptive context - in a non generic way
    - Hosts scam, malware, or deceptive content pretending to be the brand - only relevant for comapny! you have to find `{company_name}` in the HTML of the login page.
 
    Set `"malicious": false` if:
    - It redirects to or embeds official company content or redirect to `{high_conf_domain}`.
    - It links to the official company site without impersonation.
    - It’s clearly a legitimate brand-owned page (even if not listed).
    - It’s parked, inactive, or contains only generic info.
    - if no strong evidence exists to prove the domain is malicious.
    - The explanation includes:  
    “redirect”, “placeholder”, “legitimate”, “parked”, “inactive”, “default hosting”.
 
    JSON Output (strict format)
    ```json
    {{
        "category": "<e.g. phishing, scam, parked, login, error, blank, blog, corporate>",
        "related": true/false,
        "related_reason": "<why it's related or not (based on content or branding)>",
        "malicious": true/false,
        "malicious_reason": "<why it's malicious — or 'Not related, so not evaluated'>"
    }}
 
   
    Suspected domain HTML:
    {html_content}
 
    Legitimate brand HTML:
    {domain_html}
 
    HTML of subsidiaries:
    {subsidiaries_html}
    """
   
    image_paths = []
   
    # Add suspected domain and brand domain if they exist
    if os.path.exists(f'images/{low_conf_domain}.png') and os.path.exists(f'images/{high_conf_domain}.png'):
        image_paths.extend([f'images/{low_conf_domain}.png', f'images/{high_conf_domain}.png'])
       
        # Add subsidiaries screenshots if they exist
        for subsidiary in subsidiaries:
            if os.path.exists(f'images/{subsidiary}.png'):
                image_paths.append(f'images/{subsidiary}.png')
       
        prompt += """
            The first image is the screenshot of the suspected domain.
            The second image is the screenshot of the brand domain.
            Any additional images are screenshots of subsidiary domains.
        """
        return analyze_images(image_paths, prompt)
 
    # if images does not exist
    return ask_openai(prompt)
   
 
def gpt_analyse_href(subdomain, domain, href, href_html):
    if not href_html or not any(href_html.get(k) for k in ['title', 'body_text']):
        return []
 
    prompt = f"""
    I'm analyzing an external link ({href}) found on subdomain {subdomain} under the legitimate domain {domain}.
    Please analyze this linked page's HTML content to determine if it contains malicious content:
 
    1. Check for clear signs of:
       - Phishing attempts
       - Malware distribution
       - Scam/fraud content
       - Unauthorized crypto/gambling sites
       - Content that clearly doesn't belong on {domain}'s business
 
    Return a JSON object with:
    - "malicious": true/false based on clear evidence only
    - "reason": brief explanation if malicious, single sentence only
 
    IMPORTANT: Only mark as malicious if there is strong, unambiguous evidence of malicious intent.
    Do not flag legitimate business/corporate content, standard login pages, or generic error pages.
    When in doubt, mark as non-malicious.
 
    Here's the HTML content to analyze:
    {href_html}
    """
    return ask_openai(prompt)
 
 
def extract_unique_hrefs(hrefs, low_conf_domain):
    seen = {}
    for href in hrefs:
        try:
            domain = urlparse(href).netloc.lower()
            if not domain:
                continue
            parts = domain.split('.')
            if len(parts) > 2:
                domain = '.'.join(parts[-2:])
            if domain in GENERIC_DOMAINS or domain in seen or low_conf_domain in href:
                continue
            seen[domain] = href
            if len(seen) > HREF_THRESHOLD:
                break
        except:
            continue
    return list(seen.values())
 
 
def analyse_html_domains(high_conf_domain, company_name, low_conf_domain, subsidiaries):
    print(f"got into html analysing with : {low_conf_domain}")
    output_path = f"html_analysis/{low_conf_domain}.json"
    if os.path.exists(output_path):
        with open(output_path, "r", encoding="utf-8") as f:
            return json.load(f)
 
    results = {
        "domain": low_conf_domain,
        "gpt_analyse": {},
        "gpt_malicious_hrefs": [],
        "content": None,
        "href_content": None
    }
 
    html_content = None
    if os.path.exists(f'html/{low_conf_domain}_html.json'):
        with open(f'html/{low_conf_domain}_html.json', 'r', encoding='utf-8') as f:
            html_content = json.load(f)
 
    results["content"] = html_content
   
    if os.path.exists(f'html/{high_conf_domain}_html.json'):
        with open(f'html/{high_conf_domain}_html.json', 'r', encoding='utf-8') as f:
            domain_html = json.load(f)
    else:
        domain_html = 'None'
 
    results["gpt_analyse"] = gpt_analyse(low_conf_domain, high_conf_domain, html_content, domain_html, subsidiaries, company_name)
 
    save_to_json(results, output_path)
    return results
 
 
def analyse_html_wrapper(high_conf_domain, company_name, low_conf_domain, subsidiaries):
    return analyse_html_domains(high_conf_domain, company_name, low_conf_domain, subsidiaries)
 
 
 
def write_all_html_analysis(high_conf_domain, company_name, low_conf_domains, subsidiaries):
    low_conf_domains = [d for d in low_conf_domains if not os.path.exists(f'html_analysis/{d}.json')]

    malicious_results = []
    related_results = []

    with concurrent.futures.ProcessPoolExecutor(max_workers=10) as executor:
        futures = {
            executor.submit(analyse_html_wrapper, high_conf_domain, company_name, low_conf_domain, subsidiaries): low_conf_domain
            for low_conf_domain in low_conf_domains
        }

        for future in concurrent.futures.as_completed(futures):
            domain = futures[future]
            try:
                result = future.result()
                gpt = result.get("gpt_analyse", {})

                if gpt.get("related") is True:
                    related_results.append(result)

                if gpt.get("malicious") is True:
                    malicious_results.append(result)

            except Exception as e:
                print(f"[Error] analysing domain {domain}: {e}")

    return malicious_results, related_results
