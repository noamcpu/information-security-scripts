import json
import os
import re
from queries.athena import query_athena, order_query_result
from queries.firebolt_queries import execute_query
import pandas as pd


# quering like %% to deal with advanced results such as CyberArk
def get_athena_for_single_word(word):
    query = f"""
        SELECT
        domain_name, create_date, expiry_date, domain_registrar_name,
        registrant_name, registrant_company, registrant_email, registrant_phone,
        administrative_name, administrative_company, administrative_email, administrative_phone,
        technical_name, technical_company, technical_email, technical_phone,
        billing_name, billing_company, billing_email, billing_phone
        FROM silver_db.bucketed_whois_data where domain_name IN (
            SELECT domain_name
            FROM silver_db.bucketed_whois_data WHERE
            LOWER(registrant_company) LIKE '%{word}%' OR LOWER(registrant_name) LIKE  '%{word}%'
        )
    """
    df = query_athena(query)
    return df

def build_query(name_list):
    where_clause = "(\n" + "\nUNION\n\n".join([
        f"-- Search in company names\n" +
        "\nUNION\n".join([
            f"SELECT 'company' AS source, {i+1} AS pos, domain, word_number, start_position\n"
            f"FROM whois_company_ngrams\n"
            f"WHERE n_gram = '{name}'"
            for i, name in enumerate(name_list)
        ]) +
        "\n\nUNION\n\n" +
        f"-- Search in registrant names\n" +
        "\nUNION\n".join([
            f"SELECT 'name' AS source, {i+1} AS pos, domain, word_number, start_position\n"
            f"FROM whois_name_ngrams\n"
            f"WHERE n_gram = '{name}'"
            for i, name in enumerate(name_list)
        ])
    ]) + "\n)"

    return f"""
    WITH whois_domains_ngrams_search AS {where_clause}
     , combined_ngrams_win AS (
        SELECT
            source,
            RANK() OVER(PARTITION BY source, domain ORDER BY pos) AS r_id,
            RANK() OVER(PARTITION BY source, domain ORDER BY word_number, start_position) AS word_pos,
            pos, domain, word_number, start_position
        FROM whois_domains_ngrams_search
    )
    SELECT
        domain_name, create_date, expiry_date, domain_registrar_name,
        registrant_name, registrant_company, registrant_email, registrant_phone,
        administrative_name, administrative_company, administrative_email, administrative_phone,
        technical_name, technical_company, technical_email, technical_phone,
        billing_name, billing_company, billing_email, billing_phone
    FROM whois_data_v
    WHERE domain IN (
        SELECT domain
        FROM combined_ngrams_win
        WHERE r_id = {len(name_list)} AND r_id = word_pos
    )
    """


from concurrent.futures import ThreadPoolExecutor, as_completed

def run_queries_parallel(company_name_list):
    tasks = {}
    with ThreadPoolExecutor(max_workers=4) as pool:
        # ── 1. main catalog query ────────────────────────────────────────────
        tasks[pool.submit(execute_query, build_query(company_name_list))] = "catalog"

        # ── 2. optional Athena queries ───────────────────────────────────────
        if len(company_name_list) < 2 and len(company_name_list[0]) > 4:
            for word in company_name_list:                     # usually just one
                tasks[pool.submit(get_athena_for_single_word, word)] = f"athena:{word}"

        # ── 3. collect results as they complete ─────────────────────────────
        all_rows, athena_frames = [], []
        for future in as_completed(tasks):
            tag = tasks[future]
            result = future.result()           # raise here if the task failed
            if tag == "catalog":
                all_rows = result              # plain list/tuple rows
            else:
                athena_frames.append(result)   # DataFrame from Athena

    # ── 4. build & combine DataFrames ────────────────────────────────────────
    columns = [
        "domain_name", "create_date", "expiry_date", "domain_registrar_name",
        "registrant_name", "registrant_company", "registrant_email", "registrant_phone",
        "administrative_name", "administrative_company", "administrative_email", "administrative_phone",
        "technical_name", "technical_company", "technical_email", "technical_phone",
        "billing_name", "billing_company", "billing_email", "billing_phone",
    ]

    df_catalog = pd.DataFrame(all_rows, columns=columns)
    df_athena  = pd.concat(athena_frames, ignore_index=True) if athena_frames else pd.DataFrame(columns)

    return (
        pd.concat([df_catalog, df_athena], ignore_index=True)
          .drop_duplicates()
          .reset_index(drop=True)
    )



def get_low_conf_domains_by_name(company_name_list, company_domain):
    print(f"got into low conf domains name with : {company_name_list}")
    output_file = f"outputs/low_confidence_name_{company_domain}.json"
    if os.path.exists(output_file):
        with open(output_file, "r") as f:
            return json.load(f)

    company_name_list = [name.lower() for name in company_name_list]

    # Step 1: Query domains that contain matching ngrams
    df = run_queries_parallel(company_name_list)

    # having a copy for final filtering
    df_copy = df.copy(deep=True)

    # Step 1: Drop rows where both name and company are null or empty
    df['registrant_name'] = df['registrant_name'].fillna('').str.strip()
    df['registrant_company'] = df['registrant_company'].fillna('').str.strip()

    df = df[~((df['registrant_name'] == '') & (df['registrant_company'] == ''))]

    # Step 3: Pre-filter by simple substring presence (faster than regex)
    def contains_all_keywords(text, keywords):
        text = text.lower()
        return all(word in text for word in keywords)

    keyword_mask = df.apply(
        lambda row: (
            contains_all_keywords(row['registrant_name'], company_name_list) or
            contains_all_keywords(row['registrant_company'], company_name_list)
        ),
        axis=1
    )

    df = df[keyword_mask]

    # Step 3: Apply regex
    pattern = '.*' + '.*'.join(map(re.escape, company_name_list)) + '.*'
    regex = re.compile(pattern, re.IGNORECASE)

    # Step 4: Vectorized match
    matched_mask = (
        df['registrant_name'].str.contains(regex) |
        df['registrant_company'].str.contains(regex)
    )

    matched_domains = set(df.loc[matched_mask, 'domain_name'])
    if not matched_domains:
        with open(output_file, 'w') as f:
            json.dump([], f)
        return []

    # Step 4: use df_copy to get relevant rows
    df_copy['expiry_date'] = pd.to_datetime(df_copy['expiry_date'].str.split('.').str[0], errors='coerce')
    now = pd.Timestamp.now()

    # Step 6: For those domains, get the most recent unexpired row if available
    results = []
    for domain in matched_domains:
        domain_rows = df_copy[df_copy['domain_name'] == domain].sort_values('expiry_date', ascending=False)
        unexpired = domain_rows[domain_rows['expiry_date'] > now]
        if not unexpired.empty:
            results.append(unexpired.iloc[0])
            
    final_df = pd.DataFrame(results)
    final_df = final_df[~final_df['registrant_email'].str.contains(f"@{company_domain}", case=False, na=False)]
    final_df = order_query_result(final_df)

    # Step 6: Sort by non-empty fields richness and deduplicate by domain
    final_df['non_empty_count'] = final_df.notna().sum(axis=1)
    final_df = final_df.sort_values(['domain_name', 'non_empty_count'], ascending=[True, False])
    final_df = final_df.drop_duplicates(subset='domain_name', keep='first')
    final_df = final_df.drop(columns='non_empty_count')

    # Step 7: Format expiry date
    final_df['expiry_date'] = final_df['expiry_date'].dt.strftime("%Y-%m-%d %H:%M:%S")

    final_df.to_json(output_file, orient="records", indent=2)
    return json.loads(final_df.to_json(orient="records"))


#get_low_conf_domains_by_name(['cyberark'], 'cyberark.com')