import ipaddress
import boto3
import time
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed


athena_client = athena_client = boto3.client(
        "athena",
        aws_access_key_id= "AKIA5G2VGXEMKAOFN2AI",
        aws_secret_access_key= "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",
        region_name= "us-east-1"
    )


def run_athena_query(query):
    try:
        response = athena_client.start_query_execution(
            QueryString=query,
            QueryExecutionContext={'Database': "silver_db"},
            ResultConfiguration={'OutputLocation': "s3://athena-query-results-908027410712-us-east-1/"}
        )
        return response['QueryExecutionId']
    except Exception as e:
        print(f"Error starting query: {e}") 
        return None

def check_query_status(query_execution_id):
    try:
        result = athena_client.get_query_execution(QueryExecutionId=query_execution_id)
        status = result['QueryExecution']['Status']['State']
        if status in ['SUCCEEDED', 'FAILED', 'CANCELLED']:
            return status, result
        time.sleep(1)
        return check_query_status(query_execution_id)
    except Exception as e:
        print(f"Error checking query status: {e}")
        return 'FAILED', None

def get_query_results(query_execution_id):
    try:
        paginator = athena_client.get_paginator('get_query_results')
        results = []
        for page in paginator.paginate(QueryExecutionId=query_execution_id):
            results.extend(page['ResultSet']['Rows'])
        return results
    except Exception as e:
        print(f"Error fetching results: {e}")
        return []

def query_athena(query):
    query_execution_id = run_athena_query(query)
    if not query_execution_id:
        return None
    print(f"Query started with execution ID: {query_execution_id}")
    status, _ = check_query_status(query_execution_id)
    if status != 'SUCCEEDED':
        print(f"Query failed with status: {status}")
        return None
    print("Query succeeded, fetching results...")
    results = get_query_results(query_execution_id)
    if not results:
        return None
    columns = [col['VarCharValue'] for col in results[0]['Data']]
    data = [[col.get('VarCharValue', '') for col in row['Data']] for row in results[1:]]
    df = pd.DataFrame(data, columns=columns)
    print("Query Results:")
    print(df)
    return df

def order_query_result(df):
    if df is not None:
        # Vectorized operations for combining fields
        def combine_values(row, fields):
            return list(set(v for v in (row[field] for field in fields) if pd.notna(v) and v not in ('', 'N/A')))
        
        df['combined_company_names'] = df.apply(lambda row: combine_values(row, [
            'registrant_company', 'administrative_company', 'technical_company', 'billing_company'
        ]), axis=1)
        df['combined_registrant_names'] = df.apply(lambda row: combine_values(row, [
            'registrant_name', 'administrative_name', 'technical_name', 'billing_name'
        ]), axis=1)
        df['combined_emails'] = df.apply(lambda row: combine_values(row, [
            'registrant_email', 'administrative_email', 'technical_email', 'billing_email'
        ]), axis=1)
        df['combined_phone'] = df.apply(lambda row: combine_values(row, [
            'registrant_phone', 'administrative_phone', 'technical_phone', 'billing_phone'
        ]), axis=1)
        df.replace('', pd.NA, inplace=True)
    return df




def get_ip_info(ip_list, batch_size=100, max_workers=5):
    ip_map = {}
    if not ip_list:
        return ip_map

    try:
        ip_list = list(set(ip_list))
        ip_ints = [int(ipaddress.IPv4Address(ip)) for ip in ip_list]

        # Prepare batches
        batches = [
            (ip_list[i:i + batch_size], ip_ints[i:i + batch_size])
            for i in range(0, len(ip_list), batch_size)
        ]

        def query_batch(batch):
            batch_ips, batch_ints = batch
            query = f"""
            SELECT numeric_start_ip, numeric_end_ip, asn, as_name, type
            FROM silver_db.ipinfo_standard_company
            WHERE numeric_start_ip <= numeric_end_ip
            AND ({' OR '.join([f"{ip_int} BETWEEN numeric_start_ip AND numeric_end_ip" for ip_int in batch_ints])})
            """
            df = query_athena(query)
            results = {}
            if df is not None:
                for row in df.itertuples(index=False):
                    start_ip, end_ip, asn, as_name, type_field = row
                    if not (start_ip and end_ip):
                        continue
                    start_ip_int = int(start_ip)
                    end_ip_int = int(end_ip)
                    for ip, ip_int in zip(batch_ips, batch_ints):
                        if start_ip_int <= ip_int <= end_ip_int:
                            results[ip] = {
                                "asn": asn,
                                "isp": as_name,
                                "type": type_field
                            }
            return results

        # Run in parallel
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [executor.submit(query_batch, batch) for batch in batches]
            for future in as_completed(futures):
                result = future.result()
                ip_map.update(result)

        return ip_map

    except Exception as e:
        print(f"[!] Error in parallel batch Athena query: {e}")
        return {}
