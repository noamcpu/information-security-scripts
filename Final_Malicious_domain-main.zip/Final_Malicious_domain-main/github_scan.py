import requests
from typing import Dict, List
import os 
import json
from gpt import openai 
from concurrent.futures import ThreadPoolExecutor, as_completed

GITHUB_TOKEN = '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'
GITHUB_API_URL = 'https://api.github.com/search/code'
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), 'github_search_results')
RESULTS_PER_PAGE = 100

def get_headers() -> Dict[str, str]:
    return {
        'Authorization': f'Bearer {GITHUB_TOKEN}',  
        'Accept': 'application/vnd.github.v3+json'
    }

def build_search_query(search_string: str) -> str:
    """Build a GitHub search query with exact string matching."""
    clean_string = search_string.replace('"', '').replace('\\', '\\\\')
    return f'"{clean_string}"'

def ensure_output_dirs(search_string: str) -> str:
    """Create output directories if they don't exist and return the path."""
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
    
    search_dir = os.path.join(OUTPUT_DIR, search_string.replace('.', '_'))
    if not os.path.exists(search_dir):
        os.makedirs(search_dir)

    return search_dir

def get_file_content(raw_url: str) -> str:
    try:
        response = requests.get(raw_url, headers=get_headers(), timeout=10)
        return response.text if response.status_code == 200 else None
    except Exception as e:
        print(f"Error fetching file content: {e}")
        return None
    
def extract_domain_matches(content: str, search_string: str) -> List[str]:
    matches = []
    words = content.replace('\n', ' ').replace('\r', ' ').split()
    for word in words:
        word = word.strip('"\';,()<>[]{}').lower()
        if search_string.lower() == word:
            matches.append(word)
    return list(set(matches))

def analyze_repo_context(repo_info: Dict, domain: str) -> Dict:
    """Analyze a single repository for malicious context."""
    prompt = f"""
You are a cybersecurity analyst speciallized in finding malicious domains. Analyze if this domain appears in a malicious/suspicious context:

domain being analyzed: {domain}
Found in:
- Repository: {repo_info['repository']['full_name']}
- File Path: {repo_info['path']}

Is this domain mentioned in a malicious/suspicious context in this repository? Consider:
- Is it listed in a security/threat feed?
- Is it in a blocklist/blacklist?
- Is it mentioned in relation to malware/attacks?
- Is it in a security incident report?
- Is it flagged as suspicious/compromised?

Answer with a simple yes/no and brief explanation.
Give the response in this JSON format:
{{
  "is_malicious_context": true/false,
  "explanation": "<brief explanation why>"
}}
"""

    try:
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            max_tokens=150,
            response_format={"type": "json_object"}
        )
        return json.loads(response.choices[0].message.content)
    except Exception as e:
        print(f"[ChatGPT Error] {e}")
        return {
            "is_malicious_context": False,
            "explanation": "Analysis failed"
        }

def search_github_code(domain: str) -> Dict:
    """Search GitHub code for domain and analyze results."""
    all_results = []
    malicious_contexts = []
    page = 1
    
    try:
        query = build_search_query(domain)
        print(f"Searching for: {query}")
        while True:            
            params = {
                'q': query,
                'per_page': RESULTS_PER_PAGE,
                'page': page
            }
            response = requests.get(
                GITHUB_API_URL, 
                headers=get_headers(), 
                params=params,
                timeout=10
            )     
            if response.status_code != 200:
                break            
            data = response.json()
            current_items = data.get('items', [])         
            if not current_items:
                break             
            for item in current_items:
                all_results.append(item)
                analysis = analyze_repo_context(item, domain)
                if analysis["is_malicious_context"]:
                    malicious_contexts.append({
                        "repo": item['repository']['full_name'],
                        "explanation": analysis["explanation"]
                    })
            if len(current_items) < RESULTS_PER_PAGE:
                break
            page += 1
    except Exception as e:
        print(f"Error searching {domain}: {e}")
    total_results = len(all_results)
    malicious_score = (len(malicious_contexts) / total_results * 100) if total_results > 0 else 0
    return {
        "domain": domain,
        "total_repos": total_results,
        "malicious_repos": len(malicious_contexts),
        "malicious_score": malicious_score,
        "malicious_contexts": malicious_contexts,
        "repos": [{
            "name": r['repository']['full_name'],
            "url": r['html_url'],
            "path": r['path']
        } for r in all_results]
    }

def process_domain(domain: str) -> Dict:
    """Process a single domain and save results."""
    print(f"\n🔍 Analyzing: {domain}")
    results = search_github_code(domain)
    output_file = os.path.join(OUTPUT_DIR, f"{domain.replace('.', '_')}_analysis.json")
    try:
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump({
                'results': results
            }, f, indent=2, ensure_ascii=False)
        print(f"✅ Results saved to {output_file}")
    except Exception as e:
        print(f"Error saving results for {domain}: {e}")
    return results

def run_github_analysis(domains: List[str]) -> List[Dict]:
    """Run the analysis on a list of domains and return results."""
    all_results = []
    try:
        print(f"Starting analysis of {len(domains)} domains")
        with ThreadPoolExecutor(max_workers=10) as executor:
            future_to_domain = {
                executor.submit(process_domain, domain): domain 
                for domain in domains
            }
            for future in as_completed(future_to_domain):
                try:
                    result = future.result()
                    all_results.append(result)
                except Exception as exc:
                    domain = future_to_domain[future]
                    print(f"Error processing {domain}: {exc}")
    except Exception as e:
        print(f"An error occurred: {e}")
    return all_results

def scan_github_domain(domain):
    """
    Loads the github_search_results/{domain}_info_analysis.json file and returns
    the malicious_score, repo URLs, and explanations if available.
    """
    path = f"github_search_results/{domain}_info_analysis.json"
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        results = data.get("results", {})
        malicious_score = results.get("malicious_score", 0)
        repos = results.get("repos", [])
        malicious_contexts = results.get("malicious_contexts", [])
        return {
            "malicious_score": malicious_score,
            "repos": repos,
            "malicious_contexts": malicious_contexts
        }
    except Exception as e:
        print(f"[Error] Failed to load GitHub scan for {domain}: {e}")
        return None

#if __name__ == "__main__":
    #run_github_analysis(['cyber-ark.biz', 'opswat.info'])
