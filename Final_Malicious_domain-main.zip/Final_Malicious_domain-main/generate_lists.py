import os
import time
import json
import multiprocessing
from contextlib import contextmanager
from concurrent.futures import ProcessPoolExecutor, as_completed
from queries.high_conf_firebolt import generate_high_conf_results
from queries.low_conf_athena import validate_unique_values
from queries.low_conf_name_firebolt import get_low_conf_domains_by_name
from queries.low_conf_tlds import get_low_conf_tlds_deep
from queries.similar_domain_name import get_similar_domain_name
from gpt import ask_openai
from gpt_companies import get_subsidiaries_and_parent

os.makedirs('results', exist_ok=True)
os.makedirs('outputs', exist_ok=True)
os.makedirs('related', exist_ok=True)

@contextmanager
def measure_time(task_name, timings):
    start = time.time()
    try:
        yield
    finally:
        timings[task_name] = time.time() - start

def read_file(file_path, timings, task_name):
    with measure_time(task_name, timings):
        if not os.path.exists(file_path):
            return []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f) if file_path.endswith('.json') else [line.strip() for line in f if line.strip()]
        except Exception as e:
            print(f"[Error] Failed to read {file_path}: {e}")
            return []

def write_json_file(file_path, data, timings, task_name):
    with measure_time(task_name, timings):
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            print(f"[Error] Failed to write to {file_path}: {e}")

def safe_run(func, *args, **kwargs):
    try:
        return func(*args, **kwargs)
    except Exception as e:
        print(f"[Error] Function {func.__name__} failed with: {e}")
        return None

def normalize_results(results, original_domain):
    if not results:
        return []
    add_root = [{**d, "root_domain": original_domain} for d in results if isinstance(d, dict)]
    return add_root

def run_unique_values(domain, timings):
    with measure_time(f'validate_unique_values_{domain}', timings):
        results = safe_run(validate_unique_values, domain)
        return normalize_results(results, domain)

def run_tlds(domain, timings):
    with measure_time(f'get_tlds_deep_{domain}', timings):
        results = safe_run(get_low_conf_tlds_deep, domain)
        return normalize_results(results, domain)

def get_high_conf(domain, timings):
    with measure_time(f'generate_high_conf_results_{domain}', timings):
        data = safe_run(generate_high_conf_results, domain)
        results = normalize_results(data, domain)
        return results

def get_name_based_for_domain_and_similar_domain(domain, timings):
    with measure_time(f'get_low_conf_domains_by_name_{domain}', timings):
        prompt = f"""
        Return only a json object containing the core business name of the company associated with this domain: {domain}
        Requirements:
        - Extract the main identifying name without legal suffixes (Inc, LLC, etc)
        - Keep distinctive words that are part of the brand name
        - Return only the commonly used business name
        - Don't return generic words like "bank", "group", "cyber", "services" etc. If its a main component of the company, include it.
        Format example:
        For microsoft.com -> {{"company_name": "Microsoft"}}
        For bankofamerica.com -> {{"company_name": "Bank of America"}}
        For citi.com -> {{"company_name": "Citi Bank"}}
        Return just the JSON object with company_name key.
        """
        ai_response = safe_run(ask_openai, prompt)
        ai_name = ai_response.get('company_name', '').lower().strip().split() if ai_response else []

        if not ai_name:
            print(f"[Warning] No company name extracted for {domain}")
            return []

        with ProcessPoolExecutor(max_workers=2) as executor:
            futures = {
            executor.submit(get_low_conf_domains_by_name, ai_name, domain),
            executor.submit(get_similar_domain_name, ai_name, domain)
            }
            
            results = []
            for future in as_completed(futures):
                result =  future.result()
                if result:
                    results.extend(result)

        results = normalize_results(results, domain)
        return results

def get_low_conf(domain, high_conf_for_domain, timings):
    high_conf_domain_names = [h['domain_name'] for h in high_conf_for_domain]
    all_low_conf = []
    with ProcessPoolExecutor(max_workers=4) as executor:
        futures = {
            executor.submit(run_unique_values, domain, timings),
            executor.submit(run_tlds, domain, timings)
        }
        for future in as_completed(futures):
            result = future.result()
            all_low_conf.extend(result)

    final_results = [d for d in all_low_conf if d['domain_name'] not in high_conf_domain_names]
    return final_results

def process_domain(main_domain, company_name):
    high_output_path = f"results/high_conf_domains_{main_domain}_all.json"
    low_output_path = f"results/low_conf_domains_{main_domain}_all.json"

    # we return, as a sign that files were written
    if os.path.exists(high_output_path) and os.path.exists(low_output_path):
        return

    manager = multiprocessing.Manager()
    timings = manager.dict()

    with measure_time('total', timings):
        with measure_time('get_subsidiaries_and_parent', timings):
            try:
                root_domains = set(get_subsidiaries_and_parent(main_domain, company_name) + [main_domain])
                print(f"[Info] Retrieved {len(root_domains)} root domains for {main_domain}")
            except Exception as e:
                print(f"[Error] Failed to get subsidiaries for {main_domain}: {e}")
                root_domains = {main_domain}

        all_low_conf = []
        all_high_conf = []
        max_main_workers = 4

        with ProcessPoolExecutor(max_workers=max_main_workers) as executor:
            initial_futures = {}
            for domain in root_domains:
                print(f"[Info] Submitting initial tasks for root domain: {domain}")
                initial_futures[executor.submit(get_high_conf, domain, timings)] = (domain, 'high_conf_domains')
                initial_futures[executor.submit(get_name_based_for_domain_and_similar_domain, domain, timings)] = (domain, 'name_based_domains')

            low_conf_submission_futures = {}
            high_conf_results_per_domain = {}

            for future in as_completed(initial_futures):
                domain, category_key = initial_futures[future]
                try:
                    result = future.result()
                    if result is None:
                        print(f"[Warning] {category_key} for {domain} returned None.")
                        continue

                    if category_key == 'high_conf_domains':
                        all_high_conf.extend(result)
                        high_conf_results_per_domain[domain] = result
                        print(f"[Info] High_conf completed for {domain}. Submitting low_conf tasks.")
                        low_conf_submission_futures[executor.submit(get_low_conf, domain, result, timings)] = domain
                    else:
                        all_low_conf.extend(result)
                except Exception as e:
                    print(f"[Error] {category_key} failed for {domain}: {e}")

            for future in as_completed(low_conf_submission_futures):
                domain = low_conf_submission_futures[future]
                try:
                    result = future.result()
                    if result is not None:
                        all_low_conf.extend(result)
                except Exception as e:
                    print(f"[Error] Low_conf failed for {domain}: {e}")

        high_conf_domain_names = [h['domain_name'] for h in all_high_conf]
        final_low_conf = [d for d in all_low_conf if d['domain_name'] not in high_conf_domain_names]

        write_json_file(high_output_path, all_high_conf, timings, f'write_final_high_conf_all_{main_domain}')
        write_json_file(low_output_path, final_low_conf, timings, f'write_final_low_conf_all_{main_domain}')
        print(f"[Info] Updated results for {main_domain}")

    try:
        aggregated_timings = {}
        TIMING_CATEGORY_MAP = {
            'generate_high_conf_results_': 'High Conf Domains',
            'get_low_conf_domains_by_name_': 'Name Based Domains',
            'validate_unique_values_': 'Unique Validated Domains',
            'get_ipinfo_hosts_': 'IP Info (Hosts)',
            'get_tlds_deep_': 'TLDs',
            'get_subsidiaries_and_parent': 'Get Subsidiaries',
            'get_historical_email_registered_': 'Historical Emails',
            'get_low_conf_by_company_ns_': 'NS Similarity'
        }

        EXCLUDE_PREFIXES = (
            'cache_check_',
            'write_high_conf_results_',
            'write_historical_email_registered_',
            'write_low_conf_domains_by_name_',
            'write_low_conf_',
            'write_final_high_conf_all_',
            'write_final_low_conf_all_',
            'read_file_'
        )

        for task, time_taken in timings.items():
            if task == 'total':
                continue
            if any(task.startswith(prefix) for prefix in EXCLUDE_PREFIXES):
                continue
            for prefix, category_name in TIMING_CATEGORY_MAP.items():
                if task.startswith(prefix):
                    aggregated_timings[category_name] = aggregated_timings.get(category_name, 0.0) + time_taken
                    break

        with open(f'results/timings_{main_domain}.txt', 'w', encoding='utf-8') as f:
            ordered_categories = [
                'Get Subsidiaries',
                'High Conf Domains',
                'Name Based Domains',
                'Historical Emails',
                'Unique Validated Domains',
                'IP Info (Hosts)',
                'TLDs'
            ]
            for category in ordered_categories:
                if category in aggregated_timings:
                    f.write(f"{category}: {aggregated_timings[category]:.2f} seconds\n")
            for category, time_taken in sorted(aggregated_timings.items()):
                if category not in ordered_categories:
                    f.write(f"{category}: {time_taken:.2f} seconds\n")
            f.write(f"total_time: {timings['total']:.2f} seconds\n")
        print(f"[Info] Wrote aggregated timings for {main_domain}")
    except Exception as e:
        print(f"[Error] Failed to write aggregated timings for {main_domain}: {e}")

if __name__ == '__main__':
    process_domain('cyberark.com', 'cyberark')